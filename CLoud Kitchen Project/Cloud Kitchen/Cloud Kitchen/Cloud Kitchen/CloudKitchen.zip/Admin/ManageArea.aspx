﻿<%@ Page Title="Manage Service Areas" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master" CodeBehind="ManageArea.aspx.vb" Inherits="Cloud_Kitchen.ManageArea" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">

 <style type="text/css">
:root {
    --primary-color: #4361ee;
    --primary-dark: #3a0ca3;
    --primary-light: #eef2ff;
    --primary-gradient: linear-gradient(135deg, #4361ee, #3a0ca3);
    --secondary-color: #f72585;
    --secondary-dark: #d31876;
    --secondary-light: #feeaf3;
    --text-primary: #2d3748;
    --text-secondary: #64748b;
    --text-light: #ffffff;
    --border-color: #e2e8f0;
    --bg-light: #f8fafc;
    --bg-body: #f5f7fa;
    --success: #10b981;
    --success-dark: royalblue;
    --success-light: #ecfdf5;
    --warning: #f59e0b;
    --warning-light: #fffbeb;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
    --shadow-md: 0 4px 6px rgba(0,0,0,0.07), 0 12px 16px rgba(0,0,0,0.03);
    --shadow-lg: 0 10px 25px rgba(0,0,0,0.1);
    --shadow-focus: 0 0 0 3px rgba(67, 97, 238, 0.3);
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    --border-radius-sm: 6px;
    --border-radius-md: 10px;
    --border-radius-lg: 16px;
}

body {
    font-family: 'Poppins', sans-serif;
    color: var(--text-primary);
    background-color: var(--bg-body);
    line-height: 1.6;
}

/* Dashboard Header */
.dashboard-header {
    background: var(--primary-gradient);
    color: var(--text-light);
    padding: 2.5rem;
    margin-bottom: 2.5rem;
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-lg);
    position: relative;
    overflow: hidden;
}

.dashboard-header::before {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    height: 100%;
    width: 40%;
    //background: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48cGF0aCBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMSkiIGQ9Ik05OSA3N0w0OSAxNzdoOThsLTQ4LTEwMHoiLz48Y2lyY2xlIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjIpIiBzdHJva2Utd2lkdGg9IjIiIGN4PSI5OCIgY3k9IjgwIiByPSIzMCIvPjxwYXRoIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgZD0iTTQ2IDcwYTUgNSAwIDAxMC0xMGw1MCAxMGE1IDUgMCAwMS0yIDl6Ii8+PHBhdGggZD0iTTE0MSA1MGE1IDUgMCAwMTAtMTBsNDAgMTBhNSA1IDAgMDEtMiA5eiIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjIpIi8+PGNpcmNsZSBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMSkiIGN4PSIxNTAiIGN5PSIxNDUiIHI9IjE1Ii8+PHBhdGggZD0iTTE4IDE2MGw0MC00MCIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMikiIHN0cm9rZS13aWR0aD0iMiIvPjwvZz48L3N2Zz4=') no-repeat center center;
    opacity: 0.3;
}

.dashboard-title {
    font-size: 2.25rem;
    font-weight: 800;
    margin-bottom: 0.75rem;
    line-height: 1.2;
    position: relative;
    z-index: 2;
}

.dashboard-description {
    font-size: 1.1rem;
    opacity: 0.9;
    max-width: 60%;
    position: relative;
    z-index: 2;
}

/* Stats Container */
.stats-container {
    display: flex;
    gap: 1.75rem;
    margin-bottom: 2.5rem;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1 1 200px;
    background: white;
    border-radius: var(--border-radius-lg);
    padding: 1.75rem;
    box-shadow: var(--shadow-md);
    display: flex;
    align-items: center;
    gap: 1.75rem;
    transition: var(--transition);
    border: 1px solid rgba(230, 235, 245, 0.8);
    position: relative;
    overflow: hidden;
}

.stat-card::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--primary-gradient);
    transform: scaleX(0);
    transform-origin: left;
    transition: transform 0.4s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
}

.stat-card:hover::after {
    transform: scaleX(1);
}

.stat-icon {
    background: var(--primary-light);
    width: 70px;
    height: 70px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.75rem;
    color: var(--primary-color);
    position: relative;
    overflow: hidden;
}

.stat-icon::before {
    content: '';
    position: absolute;
    top: -10px;
    right: -10px;
    width: 40px;
    height: 40px;
    background: rgba(67, 97, 238, 0.2);
    border-radius: 50%;
}

.stat-info {
    flex-grow: 1;
}

.stat-value {
    font-size: 2.25rem;
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
    line-height: 1.2;
    background: var(--primary-gradient);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
}

.stat-label {
    font-size: 1rem;
    font-weight: 500;
    color: var(--text-secondary);
    letter-spacing: 0.3px;
}

/* Panels and Containers */
.update-panel {
    position: relative;
    padding: 2.5rem;
    background: #ffffff; 
    border-radius: var(--border-radius-lg);
    box-shadow: var(--shadow-md);
    max-width: 100%;
    width: 100%;
    margin: 0 auto 2.5rem;
    transition: var(--transition);
    border: 1px solid rgba(230, 235, 245, 0.8);
}

.floating-panel {
    position: fixed; 
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2050; 
    max-height: 85vh;
    overflow-y: auto;
    background: #ffffff;
    border-radius: var(--border-radius-lg);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.25);
    width: 500px;
    max-width: 95%;
    padding: 2.5rem;
    animation: fadeInScale 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    border: 1px solid rgba(230, 235, 245, 0.8);
}

.overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(17, 24, 39, 0.6);
    backdrop-filter: blur(4px);
    z-index: 2000;
    animation: fadeIn 0.25s ease-out;
}

/* Headings */
h3 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.75rem;
    color: var(--primary-color);
    text-align: center;
    font-weight: 700;
    margin-bottom: 2rem;
    position: relative;
    padding-bottom: 0.75rem;
}

h3:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 4px;
    background: var(--primary-gradient);
    border-radius: 4px;
}

.grid-manage h2 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.5rem;
    font-weight: 700;
    text-align: left;
    color: var(--text-primary);
    margin: 2.25rem 0 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.grid-manage h2 i {
    color: var(--primary-color);
    font-size: 1.3rem;
}

/* Form Elements */
.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    margin-bottom: 2rem;
}

.form-group label {
    font-size: 1rem;
    font-weight: 600;
    color: var(--text-primary);
}

input[type="text"], select {
    padding: 0.9rem 1.1rem;
    font-size: 1rem;
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius-md);
    background: #ffffff;
    transition: var(--transition);
    box-shadow: var(--shadow-sm);
}

input[type="text"]:focus, select:focus {
    border-color: var(--primary-color);
    outline: none;
    box-shadow: var(--shadow-focus);
}

.form-actions {
    display: flex;
    justify-content: flex-end;
    margin-top: 2.5rem;
    gap: 1.25rem;
}

/* Buttons */
.btn {
    padding: 0.9rem 1.75rem;
    font-size: 1rem;
    font-weight: 600;
    border: none;
    border-radius: var(--border-radius-md);
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.6rem;
    letter-spacing: 0.3px;
    box-shadow: var(--shadow-sm);
}

.btn-save {
    background: var(--primary-gradient);
    color: white;
    position: relative;
    overflow: hidden;
}

.btn-save::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: linear-gradient(rgba(255,255,255,0.2), rgba(255,255,255,0));
    opacity: 0;
    transition: opacity 0.3s;
}

.btn-save:hover {
    transform: translateY(-3px);
    box-shadow: 0 7px 14px rgba(67, 97, 238, 0.3);
}

.btn-save:hover::after {
    opacity: 1;
}

.btn-cancel {
    background: #f1f5f9;
    color: var(--text-secondary);
    position: relative;
    overflow: hidden;
}

.btn-cancel:hover {
    background: #e2e8f0;
    transform: translateY(-3px);
    box-shadow: var(--shadow-md);
}

.btn-add {
    background: var(--success);
    color: white;
    margin-bottom: 1.75rem;
    align-self: flex-start;
    position: relative;
    overflow: hidden;
}

.btn-add::after {
    content: '';
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: linear-gradient(rgba(255,255,255,0.2), rgba(255,255,255,0));
    opacity: 0;
    transition: opacity 0.3s;
}

.btn-add:hover {
    background: var(--success-dark);
    transform: translateY(-3px);
    box-shadow: 0 7px 14px rgba(16, 185, 129, 0.25);
}

.btn-add:hover::after {
    opacity: 1;
}

/* Tables */
table.table-bordered {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 1.5rem;
    box-shadow: var(--shadow-md);
    border-radius: var(--border-radius-lg);
    overflow: hidden;
    border: 1px solid rgba(230, 235, 245, 0.8);
}

table.table-bordered thead {
    background: var(--primary-gradient);
    color: white;
    font-weight: 600;
}

table.table-bordered th, table.table-bordered td {
    padding: 1.2rem 1.5rem;
    border: 1px solid var(--border-color);
    text-align: left;
    font-size: 1rem;
}

table.table-bordered th {
    text-transform: uppercase;
    font-size: 0.9rem;
    letter-spacing: 1px;
    font-weight: 700;
}

table.table-bordered tbody tr:nth-child(even) {
    background: rgba(243, 246, 252, 0.7);
}

table.table-bordered tbody tr {
    transition: var(--transition);
}

table.table-bordered tbody tr:hover {
    background: var(--primary-light);
    transform: translateX(5px);
}

.action-buttons {
    display: flex;
    gap: 0.75rem;
}

.btn-table {
    padding: 0.6rem 1.25rem;
    font-size: 0.9rem;
    border-radius: var(--border-radius-sm);
    transition: var(--transition);
}

.btn-edit {
    background: var(--primary-color);
    color: white;
}

.btn-edit:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(67, 97, 238, 0.25);
}

.btn-delete {
    background: var(--secondary-color);
    color: white;
}

.btn-delete:hover {
    background: var(--secondary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(247, 37, 133, 0.25);
}

/* Messages and Notifications */
.lblmsg {
    color: var(--secondary-color);
    text-align: center;
    font-size: 1rem;
    font-weight: 500;
}

.message {
    text-align: center;
    font-size: 1rem;
    padding: 1.25rem;
    border-radius: var(--border-radius-md);
    margin: 1.5rem 0;
    animation: slideDown 0.3s ease-out;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
}

.message::before {
    font-family: 'FontAwesome';
    font-size: 1.2rem;
}

.message.success {
    background-color: var(--success-light);
    color: var(--success-dark);
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.message.success::before {
    content: "\f058"; /* checkmark */
    color: var(--success);
}

.message.error {
    background-color: var(--secondary-light);
    color: var(--secondary-dark);
    border: 1px solid rgba(247, 37, 133, 0.2);
}

.message.error::before {
    content: "\f057"; /* x mark */
    color: var(--secondary-color);
}

.no-data {
    text-align: center;
    padding: 3rem 2rem;
    color: var(--text-secondary);
    font-style: italic;
    background-color: var(--bg-light);
    border-radius: var(--border-radius-lg);
    margin-top: 1.5rem;
    border: 2px dashed var(--border-color);
}

/* Search Bar */
.search-bar {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    align-items: center;
    background: var(--bg-light);
    padding: 0.75rem;
    border-radius: var(--border-radius-md);
    border: 1px solid var(--border-color);
}

.search-bar input {
    flex-grow: 1;
    max-width: 400px;
    border: 1px solid rgba(230, 235, 245, 0.8);
}

.search-bar .btn {
    padding: 0.75rem 1.25rem;
}

/* Confirmation Dialog */
.confirmation-dialog {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 2rem;
    border-radius: var(--border-radius-lg);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    z-index: 3000;
    max-width: 450px;
    width: 90%;
    animation: fadeInScale 0.3s ease-out;
    border: 1px solid var(--border-color);
}

.confirmation-title {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 1.25rem;
    color: var(--text-primary);
}

.confirmation-message {
    margin-bottom: 2rem;
    color: var(--text-secondary);
    line-height: 1.6;
}

.confirmation-buttons {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
}

/* Animations */
@keyframes fadeIn {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

@keyframes slideDown {
    0% { transform: translateY(-20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}

@keyframes fadeInScale {
    0% { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }
    100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .stats-container {
        flex-direction: column;
    }
    
    .stat-card {
        max-width: 100%;
    }
}

@media (max-width: 768px) {
    .dashboard-header {
        padding: 2rem;
    }
    
    .update-panel {
        padding: 1.75rem;
    }
    
    .floating-panel {
        padding: 1.75rem;
    }

    .form-actions {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
    
    .search-bar {
        flex-wrap: wrap;
    }
    
    .search-bar input {
        max-width: 100%;
    }
    
    table.table-bordered th, table.table-bordered td {
        padding: 1rem;
        font-size: 0.9rem;
    }
}

@media (max-width: 480px) {
    .dashboard-header {
        padding: 1.75rem;
    }
    
    .dashboard-title {
        font-size: 1.75rem;
    }
    
    .floating-panel {
        width: 100%;
        height: 100%;
        max-height: 100%;
        border-radius: 0;
        top: 0;
        left: 0;
        transform: none;
    }
    
    .stat-card {
        padding: 1.25rem;
    }
    
    .stat-icon {
        width: 60px;
        height: 60px;
        font-size: 1.5rem;
    }
    
    .stat-value {
        font-size: 1.75rem;
    }
}

/* Font Awesome fix */
.fa {
    display: inline-block;
    width: 1em;
    height: 1em;
    line-height: 1;
    text-align: center;
}

/* Custom error messages styling */
.error-message {
    color: var(--secondary-color);
    font-size: 0.85rem;
    margin-top: 0.35rem;
    display: block;
    animation: fadeIn 0.3s ease;
}

/* Custom input validation styling */
input.error {
    border-color: var(--secondary-color);
    background-color: var(--secondary-light);
}

/* Focus states for better accessibility */
*:focus-visible {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}

/* Smooth scrolling */
html {
    scroll-behavior: smooth;
}    --primary-color: #4a6cf7;
    --primary-dark: #3a56d4;
    --primary-light: #eef2ff;
    --secondary-color: #f44336;
    --secondary-dark: #d32f2f;
    --text-primary: #2d3748;
    --text-light: #ffffff;
    --border-color: #e2e8f0;
    --bg-light: #f8fafc;
    --success: #10b981;
    --warning: #f59e0b;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.1);
    --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
    --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
    --transition: all 0.3s ease;
}

body {
    font-family: 'Poppins', sans-serif;
    color: var(--text-primary);
    background-color: #f5f7fa;
}

.dashboard-header {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: var(--text-light);
    padding: 2rem;
    margin-bottom: 2rem;
    border-radius: 12px;
    box-shadow: var(--shadow-lg);
}

.dashboard-title {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.dashboard-description {
    font-size: 1rem;
    opacity: 0.9;
}

.update-panel {
    position: relative;
    padding: 2rem;
    background: #ffffff; 
    border-radius: 12px;
    box-shadow: var(--shadow-md);
    max-width: 100%;
    width: 100%;
    margin: 0 auto 2rem;
    transition: var(--transition);
}

.floating-panel {
    position: fixed; 
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 2050; 
    max-height: 85vh;
    overflow-y: auto;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    width: 500px;
    max-width: 95%;
    padding: 2rem;
    animation: fadeInScale 0.3s ease-out;
}

.overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(4px);
    z-index: 2000;
    animation: fadeIn 0.2s ease-out;
    //display:none;
}

h3 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.5rem;
    color: var(--primary-color);
    text-align: center;
    font-weight: 700;
    margin-bottom: 1.5rem;
    position: relative;
    padding-bottom: 0.5rem;
}

h3:after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 50px;
    height: 3px;
    background: var(--primary-color);
    border-radius: 3px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
}

.form-group label {
    font-size: 0.95rem;
    font-weight: 600;
    color: var(--text-primary);
}

input[type="text"], select {
    padding: 0.75rem 1rem;
    font-size: 0.95rem;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background: #ffffff;
    transition: var(--transition);
}

input[type="text"]:focus, select:focus {
    border-color: var(--primary-color);
    outline: none;
    box-shadow: 0 0 0 3px rgba(74, 108, 247, 0.1);
}

.form-actions {
    display: flex;
    justify-content: flex-end;
    margin-top: 2rem;
    gap: 1rem;
}

.btn {
    padding: 0.75rem 1.5rem;
    font-size: 0.95rem;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.btn-save {
    background: var(--primary-color);
    color: white;
}

.btn-save:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.btn-cancel {
    background: #f1f5f9;
    color: #64748b;
}

.btn-cancel:hover {
    background: #e2e8f0;
    transform: translateY(-2px);
    box-shadow: var(--shadow-sm);
}

.btn-add {
    background: var(--success);
    color: white;
    margin-bottom: 1.5rem;
    align-self: flex-start;
}

.btn-add:hover {
    background: #0ca678;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(16, 185, 129, 0.2);
}

.grid-manage h2 {
    font-family: 'Poppins', sans-serif;
    font-size: 1.25rem;
    font-weight: 700;
    text-align: left;
    color: var(--text-primary);
    margin: 2rem 0 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.grid-manage h2 i {
    color: var(--primary-color);
}

table.table-bordered {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 1rem;
    box-shadow: var(--shadow-md);
    border-radius: 10px;
    overflow: hidden;
}

table.table-bordered thead {
    background: var(--primary-color);
    color: white;
    font-weight: 600;
}

table.table-bordered th, table.table-bordered td {
    padding: 1rem;
    border: 1px solid var(--border-color);
    text-align: left;
    font-size: 0.95rem;
}

table.table-bordered th {
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 0.5px;
}

table.table-bordered tbody tr:nth-child(even) {
    background: var(--bg-light);
}

table.table-bordered tbody tr:hover {
    background: var(--primary-light);
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.btn-table {
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
    border-radius: 6px;
}

.btn-edit {
    background: var(--primary-color);
    color: white;
}

.btn-edit:hover {
    background: var(--primary-dark);
}

.btn-delete {
    background: var(--secondary-color);
    color: white;
}

.btn-delete:hover {
    background: var(--secondary-dark);
}

.lblmsg {
    color: var(--secondary-color);
    text-align: center;
    font-size: 0.95rem;
    font-weight: 500;
}

.message {
    text-align: center;
    font-size: 0.95rem;
    padding: 1rem;
    border-radius: 8px;
    margin: 1rem 0;
    animation: slideDown 0.3s ease-out;
}

.message.success {
    background-color: rgba(16, 185, 129, 0.1);
    color: #065f46;
    border: 1px solid rgba(16, 185, 129, 0.2);
}

.message.error {
    background-color: rgba(244, 67, 54, 0.1);
    color: #b91c1c;
    border: 1px solid rgba(244, 67, 54, 0.2);
}

.no-data {
    text-align: center;
    padding: 2rem;
    color: #64748b;
    font-style: italic;
    background-color: var(--bg-light);
    border-radius: 10px;
    margin-top: 1rem;
}

.stats-container {
    display: flex;
    gap: 1.5rem;
    margin-bottom: 2rem;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1 1 200px;
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: var(--shadow-md);
    display: flex;
    align-items: center;
    gap: 1.5rem;
    transition: var(--transition);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-lg);
}

.stat-icon {
    background: var(--primary-light);
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--primary-color);
}

.stat-info {
    flex-grow: 1;
}

.stat-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
}

.stat-label {
    font-size: 0.9rem;
    color: #64748b;
}

.search-bar {
    display: flex;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
    align-items: center;
    width:100%;
}

.search-bar input {
    flex-grow: 1;
    max-width: 420px;
}

.confirmation-dialog {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 1.5rem;
    border-radius: 12px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    z-index: 3000;
    max-width: 400px;
    width: 90%;
    animation: fadeInScale 0.3s ease-out;
}

.confirmation-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 1rem;
    color: var(--text-primary);
}

.confirmation-message {
    margin-bottom: 1.5rem;
    color: #4b5563;
    line-height: 1.5;
}

.confirmation-buttons {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
}

@keyframes fadeIn {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

@keyframes slideDown {
    0% { transform: translateY(-20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}

@keyframes fadeInScale {
    0% { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }
    100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .stats-container {
        flex-direction: column;
    }
    
    .stat-card {
        max-width: 100%;
    }
}

@media (max-width: 768px) {
    .update-panel {
        padding: 1.5rem;
    }
    
    .floating-panel {
        padding: 1.5rem;
    }

    .form-actions {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
    
    .search-bar {
        flex-wrap: wrap;
    }
    
    .search-bar input {
        max-width: 100%;
    }
    
    table.table-bordered th, table.table-bordered td {
        padding: 0.75rem;
        font-size: 0.85rem;
    }
}

@media (max-width: 480px) {
    .dashboard-header {
        padding: 1.5rem;
    }
    
    .dashboard-title {
        font-size: 1.5rem;
    }
    
    .floating-panel {
        width: 100%;
        height: 100%;
        max-height: 100%;
        border-radius: 0;
        top: 0;
        left: 0;
        transform: none;
    }
}




.fa {
    display: inline-block;
    width: 1em;
    height: 1em;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
}

.fa-map-marker:before {
    content: "📍";
}

.fa-plus:before {
    content: "➕";
}

.fa-edit:before {
    content: "✏️";
}

.fa-trash:before {
    content: "🗑️";
}

.fa-search:before {
    content: "🔍";
}

.fa-list:before {
    content: "📋";
}

.fa-home:before {
    content: "🏠";
}

.fa-map:before {
    content: "🗺️";
}
 </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:ScriptManager ID="ScriptManager1" runat="server">
    </asp:ScriptManager>

    <div class="dashboard-header">
        <h1 class="dashboard-title">Service Area Management</h1>
        <p class="dashboard-description">Manage delivery areas and pincodes for your cloud kitchen service</p>
    </div>

    <div class="stats-container">
        <div class="stat-card">
            <div class="stat-icon">
                <img src="../icons/loc2.png" style="width: 40px; " />
            </div>
            <div class="stat-info">
                <div class="stat-value">
                    <asp:Literal ID="litTotalAreas" runat="server">12</asp:Literal>
                </div>
                <div class="stat-label">Total Areas</div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">
                <img src="../icons/track.png" style="width: 40px; " />
            </div>
            <div class="stat-info">
                <div class="stat-value">
                    <asp:Literal ID="litRecentAdditions" runat="server">3</asp:Literal>
                </div>
                <div class="stat-label">Recent Additions</div>
            </div>
        </div>
    </div>
    
    <div id="messagePanel" class="message success" style="display: none;">
        <asp:Literal ID="litMessage" runat="server"></asp:Literal>
    </div>
    
    <div class="update-panel">
        <asp:Button ID="btnAddNew" runat="server" Text="➕ Add New Area" CssClass="btn btn-add" OnClick="btnAddNew_Click" CausesValidation="false" />
        
        <div class="search-bar">
            <asp:TextBox ID="txtSearch" runat="server" placeholder="Search by area name or pincode..." width="150%"/>
            <asp:Button ID="btnSearch" runat="server" Text="🔍 Search" CssClass="btn btn-save" OnClick="btnSearch_Click" CausesValidation="false" />
            <asp:Button ID="btnClearSearch" runat="server" Text="Clear" CssClass="btn btn-cancel" OnClick="btnClearSearch_Click" CausesValidation="false" />
        </div>
        
        <div class="grid-manage">
            <h2><img src="../icons/loc1.png" style="width: 40px; " /> Service Areas List</h2>
            <asp:HiddenField ID="hdnDeleteAreaId" runat="server" />
            <!-- Areas Grid -->
            <asp:Repeater ID="rptArea" runat="server" OnItemCommand="rptArea_ItemCommand">
                <HeaderTemplate>
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Area Name</th>
                                <th>Pincode</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                </HeaderTemplate>
                <ItemTemplate>
                    <tr>
                        <td><%# Eval("Area_Name") %></td>
                        <td><%# Eval("Pincode") %></td>
                        <td class="action-buttons">
                            <asp:Button ID="btnEdit" runat="server" CssClass="btn btn-table btn-edit" CommandName="EditArea" CommandArgument='<%# Eval("Area_Id") %>' Text="✏️ Edit" CausesValidation="false" />

                        </td>
                    </tr>
                </ItemTemplate>
                <FooterTemplate>
                    </tbody>
                    </table>
                </FooterTemplate>
            </asp:Repeater>
            
            <asp:Panel ID="pnlNoData" runat="server" CssClass="no-data" Visible="false">
                <p>No service areas found. Click "Add New Area" to create one.</p>
            </asp:Panel>
        </div>
    </div>
    
<asp:Panel ID="Panel1" runat="server" CssClass="panel-class" Visible="false">
    <div id="overlay" class="overlay" runat="server"></div>
</asp:Panel>

    
    
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <asp:Panel ID="pnlEditArea" Visible="false" runat="server" CssClass="floating-panel">
                <h3>
                    <asp:Literal ID="litPanelTitle" runat="server">Add New Service Area</asp:Literal>
                </h3>

                <asp:HiddenField ID="hfAreaId" runat="server" />

                <div class="form-group">
                    <label for="txtArea">Area Name</label>
                    <asp:TextBox ID="txtArea" runat="server" CssClass="form-control" placeholder="Enter area name (e.g. Downtown, Westside)" ></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvFullName" runat="server" ControlToValidate="txtArea" 
                        ErrorMessage="Area Name is required." Display="Dynamic" ForeColor="Red" />
                    <asp:RegularExpressionValidator 
                        ID="revFullName" 
                        runat="server" 
                        ControlToValidate="txtArea" 
                        ErrorMessage="Only alphabets and spaces are allowed." 
                        ValidationExpression="^[A-Za-z ]+$" 
                        Display="Dynamic" 
                        ForeColor="Red" />
                </div>

                <div class="form-group">
                    <label for="txtPincode">Pincode</label>
                    <asp:TextBox ID="txtPincode" runat="server" CssClass="form-control" placeholder="Enter 6-digit pincode" ></asp:TextBox>
                     <asp:RequiredFieldValidator ID="rfvPincode" runat="server" ControlToValidate="txtPincode"
                            ErrorMessage="Pincode is required" CssClass="error-message" Display="Dynamic"
                             ForeColor="red"></asp:RequiredFieldValidator>
                     <asp:RegularExpressionValidator ID="revPincode" runat="server" ControlToValidate="txtPincode"
                            ErrorMessage="Must be a valid 6-digit pincode" ValidationExpression="^\d{6}$" CssClass="error-message"
                            Display="Dynamic" ForeColor="red"></asp:RegularExpressionValidator>
                </div>

                <div class="form-group lblmsg">
                    <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
                </div>

                <div class="form-actions">
                    <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn btn-save" OnClick="btnSave_Click" />
                    <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="btn btn-save" OnClick="btnUpdate_Click" Visible="False" />
                    <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-cancel" OnClick="btnCancel_Click"  CausesValidation="false" />
                </div>
            </asp:Panel>
        </ContentTemplate>
    </asp:UpdatePanel>
    

<script type="text/javascript">
    function hideAddEditPanel() {
        document.getElementById('<%= Panel1.ClientID %>').style.display = "none";
        document.getElementById('<%= overlay.ClientID %>').style.display = "none";
    }

    function showAddEditPanel() {
        document.getElementById('<%= Panel1.ClientID %>').style.display = "block";
        document.getElementById('<%= overlay.ClientID %>').style.display = "block";
    }
</script>



</asp:Content>