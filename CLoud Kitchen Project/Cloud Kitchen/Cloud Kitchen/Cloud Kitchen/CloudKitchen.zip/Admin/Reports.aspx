﻿<%@ Page Title="Reports Dashboard" Language="VB" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master" CodeBehind="Reports.aspx.vb" Inherits="Cloud_Kitchen.Reports" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        .report-container {
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            margin: 20px auto;
            max-width: 1200px;
        }

        .dashboard-header {
            margin-bottom: 30px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 15px;
        }

        .dashboard-header h2 {
            font-size: 28px;
            color: #333;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            font-weight: 600;
        }

        .dashboard-header h2 i {
            margin-right: 10px;
            color: #007BFF;
        }

        .dashboard-header p {
            color: #666;
            font-size: 16px;
            margin-top: 0;
        }

        .filter-panel {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            border: 1px solid #e9ecef;
        }

        .filter-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
            align-items: center;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #495057;
        }

        .filter-control {
            width: 100%;
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #ced4da;
            background-color: white;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .filter-control:focus {
            border-color: #007BFF;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.25);
            outline: none;
        }

        .action-row {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            gap: 8px;
        }

        .btn i {
            font-size: 18px;
        }

        .btn-primary {
            background-color: #007BFF;
            color: white;
            border: 2px solid #007BFF;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-primary:active {
            background-color: #0062cc;
            border-color: #005cbf;
            transform: translateY(0);
            box-shadow: none;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
            border: 2px solid #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-success:active {
            background-color: #1e7e34;
            border-color: #1c7430;
            transform: translateY(0);
            box-shadow: none;
        }

        .report-section {
            background: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            overflow: auto;
        }

        .report-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 15px;
        }

        .report-table th, .report-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }

        .report-table th {
            background-color: #007BFF;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-size: 14px;
            border: none;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .report-table th:first-child {
            border-top-left-radius: 8px;
        }

        .report-table th:last-child {
            border-top-right-radius: 8px;
        }

        .report-table tr:last-child td:first-child {
            border-bottom-left-radius: 8px;
        }

        .report-table tr:last-child td:last-child {
            border-bottom-right-radius: 8px;
        }

        .report-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .report-table tr:hover {
            background-color: #f1f1f1;
        }

        .report-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-top: 20px;
        }

        .report-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }

        .summary-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 20px;
            flex: 1;
            min-width: 200px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #007BFF;
        }

        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }

        .summary-title {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .summary-value {
            font-size: 24px;
            font-weight: bold;
            color: #343a40;
            margin: 0;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #6c757d;
            font-size: 18px;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 20px 0;
        }

        @media (max-width: 992px) {
            .filter-row {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-group {
                width: 100%;
            }
            
            .action-row {
                flex-direction: column;
                gap: 15px;
            }
            
            .btn {
                width: 100%;
            }
            
            .report-container {
                padding: 20px;
            }
        }

        /* Custom dropdown styling */
        select.filter-control {
            appearance: none;
            //background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23343a40' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 16px;
            padding-right: 45px;
        }

        /* Loading indicator */
        .loading {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #007BFF;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
    <!-- Add Font Awesome for better icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="report-container">
        <div class="dashboard-header">
            <h2><img src="../icons/rep2.png" alt="Total Orders" width="38"> &nbsp; Report Dashboard</h2>
            <p>Generate and analyze detailed reports for your cloud kitchen business</p>
        </div>

        <div class="filter-panel">
            <div class="filter-row">
                <div class="filter-group" style="padding-top:23px;">
                    <label for="ddlReportType" class="filter-label">💹 Report Type</label>
                                      <asp:DropDownList ID="ddlReportType" runat="server" CssClass="filter-control">
                                      <asp:ListItem Value="" Enabled="false">-- Select Report Type --</asp:ListItem>
                                        <asp:ListItem Value="orders">📃 Orders Report</asp:ListItem>
                                        <asp:ListItem Value="customers">👥 Customers Report</asp:ListItem>
                                        <asp:ListItem Value="menu">🍽️ Menu Items Report</asp:ListItem>
                                        <asp:ListItem Value="messages">📩 Contact Messages Report</asp:ListItem>
                                        <asp:ListItem Value="daily_sales">📊 Daily Sales Report</asp:ListItem>
                                        <asp:ListItem Value="top_selling">🔥 Top Selling Menu Items</asp:ListItem>
                                        <asp:ListItem Value="customer_summary">📜 Customer Order Summary</asp:ListItem>
                                        <asp:ListItem Value="active_customers">📌 Active vs Inactive Customers</asp:ListItem>
                                        <asp:ListItem Value="revenue_cuisine">🍛 Revenue by Cuisine Type</asp:ListItem>
                                        <asp:ListItem Value="order_status">🛒 Pending vs Completed Orders</asp:ListItem>
                                        <asp:ListItem Value="loyal_customers">🏆 Most Loyal Customers</asp:ListItem>
                                        <asp:ListItem Value="highest_orders">💰 Highest Total Amount Orders</asp:ListItem>
                                        <asp:ListItem Value="feedback">💬 Customer Feedback Report</asp:ListItem>
                                    </asp:DropDownList>
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                        ErrorMessage="Please select Report Type" ControlToValidate="ddlReportType" 
                        ForeColor="Red" InitialValue=""></asp:RequiredFieldValidator>

                </div>

                <div class="filter-group">
                    <label for="txtStartDate" class="filter-label"> 📅Start Date</label>
                    <asp:TextBox ID="txtStartDate" runat="server" TextMode="Date" CssClass="filter-control"></asp:TextBox>
                </div>

                <div class="filter-group">
                    <label for="txtEndDate" class="filter-label">📅End Date</label>
                    <asp:TextBox ID="txtEndDate" runat="server" TextMode="Date" CssClass="filter-control"></asp:TextBox>
                </div>
            </div>

            <asp:Button ID="btnGenerate" runat="server" Text="Generate Report" style="margin-top:10px;" CssClass="btn btn-primary" OnClick="btnGenerate_Click" OnClientClick="showLoading();" />
        </div>

        <div class="report-summary">
            <div class="summary-card">
                <div class="summary-title">Total Records</div>
                <div class="summary-value">
                    <asp:Literal ID="litTotalRecords" runat="server">0</asp:Literal>
                </div>
            </div>
            <div class="summary-card" style="border-left-color: #28a745;">
                <div class="summary-title">Date Range</div>
                <div class="summary-value" style="font-size: 18px;">
                    <asp:Literal ID="litDateRange" runat="server">All Time</asp:Literal>
                </div>
            </div>
            <div class="summary-card" style="border-left-color: #fd7e14;">
                <div class="summary-title">Last Updated</div>
                <div class="summary-value" style="font-size: 18px;">
                    <asp:Label ID="Label1" runat="server" ></asp:Label>
                </div>
            </div>
        </div>

        <div class="report-section">
            <asp:Panel ID="pnlNoData" runat="server" CssClass="no-data" Visible="false">
                <img  src="../icons/em1.png" style="width: 180px; color: #dee2e6; display: block; margin: auto; margin-bottom:30px;"  />
                <p>No data available for the selected criteria. Try adjusting your filters.</p>
            </asp:Panel>

            <!-- Report Grid -->
            <asp:GridView ID="gvReport" runat="server" CssClass="report-table" AutoGenerateColumns="true"
                EmptyDataText="<div class='no-data'><i class='fas fa-chart-bar' style='font-size: 48px; color: #dee2e6; display: block; margin-bottom: 15px;'></i><p>No data available for the selected criteria</p></div>"
                AllowPaging="true" PageSize="15" OnPageIndexChanging="gvReport_PageIndexChanging">
                <PagerSettings Mode="NumericFirstLast" FirstPageText="<<" LastPageText=">>" PageButtonCount="5" />
                <PagerStyle CssClass="pagination" HorizontalAlign="Right" />
            </asp:GridView>
        </div>

        <div class="report-actions">
            <asp:Button ID="btnExportCSV" runat="server" Text="Export to Excel" CssClass="btn btn-primary" OnClick="btnExportCSV_Click" Visible="false" />
            <asp:Button ID="btnPrint" runat="server" Text="Print Report" CssClass="btn btn-primary" OnClick="btnPrint_Click" />
        </div>
    </div>

    <div id="loadingIndicator" class="loading" style="display: none;">
        <div class="loading-spinner"></div>
    </div>

    <script type="text/javascript">
        function showLoading() {
            document.getElementById('loadingIndicator').style.display = 'flex';
            return true;
        }

        function hideLoading() {
            document.getElementById('loadingIndicator').style.display = 'none';
        }

        // Hide loading when page is loaded
        window.onload = function () {
            hideLoading();
        };
    </script>
</asp:Content>