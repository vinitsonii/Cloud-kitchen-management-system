﻿<%@ Page Title="Manage Orders" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master" CodeBehind="ManageOrders.aspx.vb" Inherits="Cloud_Kitchen.WebForm11" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    
    <style type="text/css">
        .admin-container {
            max-width: 1200px;
            margin: 30px auto;
            font-family: 'Segoe UI', Arial, sans-serif;
            padding: 25px;
            background: linear-gradient(to bottom right, #f8fdff, #e6f4ff);
            border-radius: 12px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.12);
        }

        .admin-header {
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 25px;
            color: #00264d;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding-bottom: 10px;
            border-bottom: 2px solid #007bff;
        }

        .dashboard-summary {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .summary-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .summary-card i {
            font-size: 30px;
            margin-bottom: 10px;
        }

        .summary-card.pending i {
            color: #ffc107;
        }

        .summary-card.completed i {
            color: #28a745;
        }

        .summary-card.cancelled i {
            color: #dc3545;
        }

        .summary-card.total i {
            color: #007bff;
        }

        .summary-value {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .summary-label {
            font-size: 14px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .filters {
            display: flex;
            justify-content: space-evenly;
            align-items: center;
            margin-bottom: 25px;
            background: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08);
        }

        .filter-group {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .filter-label {
            font-weight: 600;
            color: #495057;
        }
        .styled-dropdown
        {
            width:180px;
            }
        .styled-dropdown, .styled-input {
            padding: 12px 16px;
            font-size: 15px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            background: #ffffff;
            transition: all 0.3s;
            outline: none;
            box-shadow: inset 0 1px 2px rgba(0,0,0,0.075);
        }

        .styled-input {
            width: 180px;
        }

        .styled-dropdown:focus, .styled-input:focus {
            border-color: #4dabf7;
            box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25);
        }

        .btn-filter {
            padding: 12px 20px;
            font-size: 15px;
            color: #fff;
            background: #007bff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-filter:hover {
            background: #0069d9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3);
        }

        .btn-filter:active {
            transform: translateY(0);
        }

        .date-filter {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .orders-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: #ffffff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 6px 16px rgba(0, 0, 0, 0.1);
        }

        .orders-table th, .orders-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
        }

        .orders-table th {
            background:#1a66b7; // linear-gradient(to right, #004085, #1a66b7);
            color: white;
            font-size: 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .orders-table tr:last-child td {
            border-bottom: none;
        }

        .orders-table tr:nth-child(even) {
            background: #f8fbff;
        }

        .orders-table tr:hover {
            background: #e6f2ff;
        }

        .status-badge {
            padding: 6px 12px;
            font-size: 13px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }

        .status-cancelled {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-update, .btn-cancel {
            padding: 7px 12px;
            font-size: 14px;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin: 0 5px;
        }

        .btn-update {
            background: #007bff;
        }

        .btn-update:hover {
            background: #007bff;
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .btn-cancel {
            background: #dc3545;
        }

        .btn-cancel:hover {
            background: #c82333;
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }

        .toggle-btn {
            cursor: pointer;
            color: #007bff;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .toggle-btn:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .toggle-btn i {
            transition: transform 0.3s;
        }

        .rotate-icon {
            transform: rotate(180deg);
        }

        .order-items {
            display: none;
            background: #f1f9ff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0px 3px 8px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
            transition: all 0.3s ease-in-out;
        }

        .item-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }

        .item-row:last-child {
            border-bottom: none;
        }

        .item-name {
            font-weight: 500;
            color: #495057;
        }

        .item-quantity {
            background: #e9ecef;
            color: #495057;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 14px;
        }

        .item-price {
            color: #28a745;
            font-weight: 500;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 25px;
            gap: 10px;
        }

        .page-item {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            border: 1px solid #dee2e6;
            background: white;
        }

        .page-item:hover:not(.active) {
            background: #e9ecef;
        }

        .page-item.active {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .empty-message {
            text-align: center;
            padding: 40px;
            font-size: 18px;
            color: #6c757d;
        }

        .customer-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .customer-avatar {
            width: 40px;
            height: 40px;
            background: #e9ecef;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            color: #495057;
        }

        .customer-details {
            display: flex;
            flex-direction: column;
        }

        .customer-name {
            font-weight: 600;
            color: #212529;
        }

        .customer-phone {
            font-size: 13px;
            color: #6c757d;
        }

        @media (max-width: 992px) {
            .dashboard-summary {
                grid-template-columns: repeat(2, 1fr);
            }

            .filters {
                flex-direction: column;
                gap: 15px;
            }

            .filter-group {
                width: 100%;
            }

            .orders-table {
                display: block;
                overflow-x: auto;
            }
        }

        @media (max-width: 576px) {
            .dashboard-summary {
                grid-template-columns: 1fr;
            }

            .filter-group {
                flex-direction: column;
                align-items: flex-start;
            }

            .styled-input {
                width: 100%;
            }
        }
    </style>

    <script type="text/javascript">
        function toggleItems(orderId) {
            var element = document.getElementById("items-" + orderId);
            var icon = document.getElementById("icon-" + orderId);

            if (element.style.display === "none" || element.style.display === "") {
                element.style.display = "block";
                icon.classList.add("rotate-icon");
            } else {
                element.style.display = "none";
                icon.classList.remove("rotate-icon");
            }
        }
    </script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="admin-container">
        <div class="admin-header">Manage Orders</div>

        <div class="dashboard-summary">
            <div class="summary-card pending">
                <img src="../icons/pen.png" alt="Pending Orders" width="30">
                <div class="summary-value">
                    <asp:Literal ID="litPendingOrders" runat="server">0</asp:Literal>
                </div>
                <div class="summary-label">Pending Orders</div>
            </div>
            <div class="summary-card completed">
                <img src="../icons/comm1.png" alt="Completed Orders" width="30">
                <div class="summary-value">
                    <asp:Literal ID="litCompletedOrders" runat="server">0</asp:Literal>
                </div>
                <div class="summary-label">Completed Orders</div>
            </div>
            <div class="summary-card cancelled">
                <img src="../icons/c3.png" alt="Cancelled Orders" width="30">
                <div class="summary-value">
                    <asp:Literal ID="litCancelledOrders" runat="server">0</asp:Literal>
                </div>
                <div class="summary-label">Cancelled Orders</div>
            </div>
            <div class="summary-card total">
                <img src="../icons/total.png" alt="Total Orders" width="30">
                <div class="summary-value">
                    <asp:Literal ID="litTotalOrders" runat="server">0</asp:Literal>
                </div>
                <div class="summary-label">Total Orders</div>
            </div>
        </div>




   <%--     <div class="filters">

        
  
        </div>--%>

       <div class="filters">





             <div class="filter-group">
                <span class="filter-label">Status:</span>
                <asp:DropDownList ID="ddlFilterStatus" runat="server" AutoPostBack="true" CssClass="styled-dropdown" OnSelectedIndexChanged="ddlFilterStatus_SelectedIndexChanged">
                    <asp:ListItem Text="All Orders" Value=""></asp:ListItem>
                    <asp:ListItem Text="Pending" Value="Pending" Selected></asp:ListItem>
                    <asp:ListItem Text="Completed" Value="Completed"></asp:ListItem>
                    <asp:ListItem Text="Cancelled" Value="Cancelled"></asp:ListItem>
                </asp:DropDownList>

            </div>



                      <div class="filter-group">
                <span class="filter-label">From :</span>
                <div class="date-filter">
                    <asp:TextBox ID="txtStartDate" runat="server" CssClass="styled-input" TextMode="Date"></asp:TextBox>
                    <span>-</span>
                    <asp:TextBox ID="txtEndDate" runat="server" CssClass="styled-input" TextMode="Date"></asp:TextBox>
                </div>
            </div>
            
               <div class="filter-group">
                <asp:TextBox ID="txtSearch" runat="server" CssClass="styled-input" placeholder="Search Here"></asp:TextBox>
                <asp:Button ID="btnFilter" runat="server" Text="Apply Filters" OnClick="btnFilter_Click" CssClass="btn-filter">
                    
                </asp:Button>
            </div>

        </div>
        <asp:Panel ID="pnlNoOrders" runat="server" CssClass="empty-message" Visible="false">
            <i class="fas fa-search" style="font-size: 48px; color: #adb5bd; margin-bottom: 15px;"></i>
            <p>No orders found matching your criteria. Try adjusting your filters.</p>
        </asp:Panel>

        <asp:Repeater ID="rptOrders" runat="server">
            <HeaderTemplate>
                <table class="orders-table">
                    <tr>
                        <th style="display:none;">Order ID</th>
                        <th>Customer</th>
                        <th>Delivery Address</th>
                        <th>Total Amount</th>
                        <th>Payment Type</th>
                        <th>Order Date</th>
                        <th>Status</th>
                        <th>Items</th>
                        <th >Actions</th>
                    </tr>
            </HeaderTemplate>
            <ItemTemplate>
                    <tr>
                        <td style="display:none;">#<%# Eval("order_id") %></td>
                        <td>
                            <div class="customer-info">
                                <div class="customer-avatar">
                                    <%# Eval("customer_name").ToString().Substring(0, 1).ToUpper() %>
                                </div>
                                <div class="customer-details">
                                    <span class="customer-name"><%# Eval("customer_name") %></span>
                                    <span class="customer-phone"><%# Eval("phone", "{0:(###) ###-####}") %></span>
                                </div>
                            </div>
                        </td>
                        <td><%# Eval("address") %>, <%# Eval("pincode") %></td>
                        <td>₹<%# Eval("total_amount", "{0:N2}") %></td>
                        <td>
                        <img src='<%# GetPaymentIcon(Eval("payment_type").ToString()) %>' class="payment-icon" width="20px"/>
                        <%# Eval("payment_type") %>
                    </td>

                        <td><%# Eval("order_date", "{0:dd-MMM-yyyy hh:mm tt}") %></td>
                        <td>
                            <span class="status-badge status-<%# Eval("order_status").ToString().ToLower() %>">
                                <%# Eval("order_status") %>
                            </span>
                        </td>
                        <td>
                            <span class="toggle-btn" onclick="toggleItems('<%# Eval("order_id") %>')">
                                <i id="icon-<%# Eval("order_id") %>" class="fas fa-chevron-down"></i>
                                View items
                            </span>
                            <div class="order-items" id="items-<%# Eval("order_id") %>">
                                <asp:Repeater ID="rptOrderItems" runat="server" DataSource='<%# Eval("OrderItems") %>'>
                                    <ItemTemplate>
                                        <div class="item-row">
                                            <span class="item-name"><%# Eval("item_name") %></span>
                                            <span class="item-quantity">x<%# Eval("quantity") %></span>
                                            <span class="item-price">₹<%# Eval("price", "{0:N2}") %></span>
                                        </div>
                                    </ItemTemplate>
                                </asp:Repeater>
                            </div>
                        </td>
                        <td style="display:flex;">
                            <asp:Button ID="btnUpdate" runat="server" Text="Complete" CssClass="btn-update" CommandArgument='<%# Eval("order_id") %>' OnClick="btnUpdate_Click" Visible='<%# Eval("order_status").ToString() = "Pending" %>' />
                            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-cancel" CommandArgument='<%# Eval("order_id") %>' OnClick="btnCancel_Click" Visible='<%# Eval("order_status").ToString() = "Pending" %>' />
                        </td>
                    </tr>
            </ItemTemplate>
            <FooterTemplate>
                </table>
            </FooterTemplate>
        </asp:Repeater>

       <div class="pagination">
    <asp:LinkButton ID="lnkFirst" runat="server" CssClass="page-item" OnClick="lnkFirst_Click">
        <img src="../icons/a1.png" alt="First Page" width="30px" />
    </asp:LinkButton>
    
    <asp:LinkButton ID="lnkPrevious" runat="server" CssClass="page-item" OnClick="lnkPrevious_Click">
        <img src="../icons/a2.png" alt="Previous Page" width="30px" />
    </asp:LinkButton>
    
    <asp:Repeater ID="rptPagination" runat="server" OnItemCommand="rptPagination_ItemCommand">
        <ItemTemplate>
            <asp:LinkButton ID="lnkPage" runat="server" CssClass='<%# IIf(Convert.ToBoolean(Eval("IsActive")), "page-item active", "page-item") %>'
                CommandName="Page" CommandArgument='<%# Eval("PageNumber") %>'>
                <%# Eval("PageNumber") %>
            </asp:LinkButton>
        </ItemTemplate>
    </asp:Repeater>
    
    <asp:LinkButton ID="lnkNext" runat="server" CssClass="page-item" OnClick="lnkNext_Click">
        <img src="../icons/a3.png" alt="Next Page" width="30px" />
    </asp:LinkButton>
    
    <asp:LinkButton ID="lnkLast" runat="server" CssClass="page-item" OnClick="lnkLast_Click">
        <img src="../icons/a4.png" alt="Last Page" width="30px" />
    </asp:LinkButton>
</div>

</asp:Content>