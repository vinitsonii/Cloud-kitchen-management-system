﻿<%@ Page Title="Dashboard" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master"
    CodeBehind="Dashboard.aspx.vb" Inherits="Cloud_Kitchen.Dashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
body {
    font-family: 'Poppins', sans-serif;
    background-color: #f0f2f5;
    overflow-x: hidden;
    color: #333;
        animation: fadeInBody 1s ease-in;
        }

        @keyframes fadeInBody {
            from {
                opacity: 0;
                
               // background:#000; 
            }
            to {
                opacity: 1;
            }
        } 
.dashboard-container {
    padding: 30px;
    animation: fadeIn 0.8s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.dashboard-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.card {
    background: linear-gradient(145deg, #ffffff, #e3e6ea);
    box-shadow: 8px 8px 15px #d1d9e6, -8px -8px 15px #ffffff;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    transition: transform 0.3s ease-in-out, box-shadow 0.3s;
    cursor: pointer;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 10px 10px 20px #c3c8d1, -10px -10px 20px #ffffff;
}

.card i {
    font-size: 40px;
    color: #007bff;
    margin-bottom: 10px;
    transition: all 0.3s;
}

.card:hover i {
    color: #0056b3;
    transform: scale(1.2);
}

.card h3 {
    font-size: 24px;
    margin: 10px 0;
    font-weight: bold;
}

.card p {
    font-size: 14px;
    color: #777;
}

.popular-items {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 20px;
    justify-content:space-around;
    
}

.item 
{

   background: #fff;
    padding: 0 0;
    border-radius: 5%;
    text-align: center;
    box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease-in-out;
    max-width: 300px;
    width:350px;
            background: linear-gradient(145deg, #ffffff, #e3e6ea);
    box-shadow: 8px 8px 15px #d1d9e6, -8px -8px 15px #ffffff;
        transition: transform 0.3s ease-in-out, box-shadow 0.3s;
    cursor: pointer;
    height:40vh;
}

.item:hover {
    transform: scale(1.05);
    box-shadow: 8px 8px 20px rgba(0, 0, 0, 0.15);
}

.item img {
    width: 100%;
    height: 70%;
    border-radius: 5%;
    //border: 3px solid #007bff;
}

.item h4 {
    font-size: 18px;
    margin-top: 10px;
}

.item p {
    font-size: 14px;
    color: #666;
}

.charts-container {
    display: flex;
    gap: 20px;
    margin-top: 30px;
    flex-wrap: wrap;
}

.chart-box {
    flex: 1;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease-in-out;
   justify-content:center;
    
}

.chart-box:hover {
    transform: scale(1.02);
}

.table-container {
    margin-top: 30px;
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
    animation: fadeInUp 0.8s ease-in-out;
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

th, td {
    padding: 14px;
    border: 1px solid #ddd;
    text-align: left;
}

th {
    background: #007bff;
    color: white;
    text-transform: uppercase;
    font-size: 14px;
}

tr:nth-child(even) { background: #f8f9fa; }
tr:hover { background: #e9ecef; transition: background 0.3s; }

@media (max-width: 768px) {
    .dashboard-cards {
        grid-template-columns: 1fr;
    }

    .charts-container {
        flex-direction: column;
    }
}

          .popular-items,  .charts-container, 
          {
            animation:appear linear;
            animation-timeline:view();
            animation-range:entry 0% cover 33%;
              }

              .table-container
              {
                              animation:appear linear;
            animation-timeline:view();
            animation-range:entry 0% cover 15%;
                  }


        @keyframes appear {
            from {
                opacity:0;
                scale:0.5;
            } to
            {
                opacity:1;
                scale:1;
                }  
        }




.animated-heading {
    text-align: center;
    font-size: 68px;
    font-weight: bold;
    font-family: 'Poppins', sans-serif;
    color: #fff;
    background: linear-gradient(135deg, #4A90E2, #1E3C72); 
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    //text-shadow: 3px 3px 10px rgba(0, 123, 255, 0.5);
    animation: fadeIn 1.5s ease-in-out, glowEffect1 2s infinite alternate;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

@keyframes glowEffect {
    from { text-shadow: 3px 3px 10px rgba(0, 123, 255, 0.5); }
    to { text-shadow: 5px 5px 15px rgba(0, 212, 255, 0.8); }
}

@media (max-width: 768px) {
    .animated-heading {
        font-size: 36px;
    }
}

#ch
{
display:grid;
place-items:center;
    }
    
    .card1
    {
        //box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
        padding:20px;
        width:80%;
        margin:auto;
        border-radius:20px;
        }
    
    
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="dashboard-container">
        <div class="card1">
            <h1 class="animated-heading" style="font-size: 55px;">
                Cloud Kitchen</h1>
        </div>
        <hr color="royalblue" size="3" width="100%" />
        <br />
        <br />
        <div class="dashboard-cards">
            <div class="card">
                <img alt="" src="../icons/cart1.png" />
                <h3>
                    <asp:Label ID="lblTotalOrders" runat="server" Text="0"></asp:Label></h3>
                <p>
                    Total Orders</p>
            </div>
            <div class="card">
                <img alt="" src="../icons/moneyy.png" />
                <h3>
                    ₹<asp:Label ID="lblTotalRevenue" runat="server" Text="0.00"></asp:Label></h3>
                <p>
                    Total Revenue</p>
            </div>
            <div class="card">
                <img alt="" src="../icons/users1.png" />
                <h3>
                    <asp:Label ID="lblActiveCustomers" runat="server" Text="0"></asp:Label></h3>
                <p>
                    Active Customers</p>
            </div>
            <div class="card">
                <img alt="" src="../icons/chef1.png" />
                <h3>
                    <asp:Label ID="lblTopDish" runat="server" Text="No Data"></asp:Label></h3>
                <p>
                    Top Selling Dish</p>
            </div>
            <br />
            <br />
        </div>
        <hr color="royalblue" size="3" width="100%" />
        <h3>
            Popular Food Items</h3>
        <div class="popular-items">
            <asp:Repeater ID="rptPopular" runat="server">
                <ItemTemplate>
                    <div class="item">
                        <img src='<%# Eval("M_Image_Url") %>' alt='<%# Eval("M_Name") %>'>
                        <h4>
                            <%# Eval("M_Name") %></h4>
                        <p>
                            Ordered
                            <%# Eval("OrderCount") %>
                            times!</p>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
        <br />
        <br />
        <hr color="royalblue" size="3" width="100%" />
        <div class="charts-container">
            <div class="chart-box" id="ch">
                <h2>
                    Sales Trend</h2>
                <br />
                <canvas id="salesChart"></canvas>
            </div>
            <div class="chart-box">
                <h2>
                    Order Status Distribution</h2>
                <br />
                <canvas id="orderStatusChart"></canvas>
            </div>
        </div>
        <div class="table-container">
            <hr color="royalblue" size="3" width="100%" />
            <h3>
                Recent Orders</h3>
            <asp:GridView ID="gvRecentOrders" runat="server" CssClass="table" AutoGenerateColumns="true">
            </asp:GridView>
        </div>
    </div>
    <asp:HiddenField ID="hfChartData" runat="server" />
    <asp:HiddenField ID="hfOrderStatusData" runat="server" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        drawSalesChart();
        drawOrderStatusChart();
    });

function drawSalesChart() {
    var rawData = document.getElementById('<%= hfChartData.ClientID %>').value;
    if (!rawData || rawData.trim() === "") {
        document.getElementById('salesChart').innerHTML = '<p>No sales data available</p>';
        return;
    }

    var chartData = JSON.parse(rawData);
    var labels = chartData.map(row => row[0]); 
    var data = chartData.map(row => row[1]); 

    var ctx = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Sales',
                data: data,
                backgroundColor: ['#4CAF50', '#FFC107', '#FF5733', '#2196F3', '#9C27B0'],
                borderColor: '#fff',
                borderWidth: 1,
                borderRadius: 5,
                barThickness: 40,
            }]
        },
        options: {
            responsive: true,
            animation: {
                duration: 1500,
                easing: 'easeOutBounce'
            }
        }
    });
}


    function drawOrderStatusChart() {
        var rawData = document.getElementById('<%= hfOrderStatusData.ClientID %>').value;
        if (!rawData || rawData.trim() === "[]") {
            document.getElementById('orderStatusChart').innerHTML = '<p>No order status data available</p>';
            return;
        }

        var chartData = JSON.parse(rawData);

        var labelMap = {};
        chartData.forEach(row => {
            var label = row[0]; 
            var count = row[1]; 
            labelMap[label] = (labelMap[label] || 0) + count;
        });

        var labels = Object.keys(labelMap);
        var data = Object.values(labelMap);

        var colors = ['#FF5733', '#FF5733','#4CAF50',  '#2196F3', '#9C27B0', '#E91E63'];

        var ctx = document.getElementById('orderStatusChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: colors,
                    borderColor: '#fff',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            color: '#333',
                            font: { size: 14, weight: 'bold' }
                        },
                        position: 'bottom'
                    }
                },
                cutout: '60%',
                animation: {
                    animateRotate: true,
                    animateScale: true
                }
            }
        });
    }
    </script>
</asp:Content>
