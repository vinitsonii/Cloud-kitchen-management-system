﻿<%@ Page Title="Contact Messages" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master"
    CodeBehind="Contact_Msg.aspx.vb" Inherits="Cloud_Kitchen.WebForm12" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        /* Main Container Styles */
        .messages-container {
            max-width: 1200px;
            margin: 30px auto;
            font-family: "Poppins", sans-serif;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0px 8px 25px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease-in-out;
        }
        
        /* Header Styles */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            border-bottom: 2px solid royalblue; 
            padding-bottom: 15px;
        }
        
        .messages-header h1
        {
             
            }
        
        .messages-header {
            font-size: 22px;
            font-weight: 600;
            color: #2c3e50;
            margin: 0;
        }
        
        .messages-stat {
            display: flex;
            gap: 20px;
        }
        
        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10px 15px;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .stat-value {
            font-size: 20px;
            font-weight: 700;
            color: #3498db;
        }
        
        .stat-label {
            font-size: 12px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Filters Section */
        .filters-section {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding: 16px;
            background-color: #f8f9fa;
            border-radius: 10px;
        }
        
        .filter-controls {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .filter-label {
            font-size: 14px;
            font-weight: 600;
            color: #495057;
        }
        
        .styled-dropdown {
            font-family: "Poppins", sans-serif;
            font-weight: 500;
            padding: 10px 16px;
            font-size: 14px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            background: #fff;
            transition: all 0.2s ease-in-out;
            cursor: pointer;
            min-width: 150px;
        }
        
        .styled-dropdown:focus {
            outline: none;
            border-color: #4dabf7;
            box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.2);
        }
        
        .search-box {
            position: relative;
            flex-grow: 1;
            max-width: 350px;
        }
        
        .search-input {
            width: 100%;
            padding: 10px 16px;
            font-family: "Poppins", sans-serif;
            font-size: 14px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            transition: all 0.2s ease-in-out;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #4dabf7;
            box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.2);
        }
        
        /* Message Grid Styles */
        .messages-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 24px;
        }
        
        /* Message Card Styles */
        .message-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease-in-out;
            border-left: 5px solid #e9ecef;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .message-card.unread {
            border-left-color: #3498db;
            background-color: #f8fbff;
        }
        
        .message-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            position: relative;
        }
        
        .message-info {
            flex-grow: 1;
        }
        
        .message-name {
            font-weight: 600;
            font-size: 17px;
            color: #2c3e50;
            margin-bottom: 4px;
        }
        
        .message-name:before {
            content: "▶ ";
            color: #3498db;
        }
        
        .message-email {
            font-size: 14px;
            color: #6c757d;
            margin-left: 12px;
        }
        
        .message-email:before {
            content: "✉ ";
            color: #6c757d;
        }
        
        .message-date {
            font-size: 12px;
            color: #000;
            margin-top: 5px;
            margin-left: 12px;
        }
        
        .message-date:before {
            content: "⏱ ";
            color: #adb5bd;
        }
        
        .message-status {
            font-size: 12px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 30px;
            background: #e9ecef;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .message-status.unread {
            background: #e3f2fd;
            color: #0d6efd;
        }
        
        .message-content {
            font-size: 15px;
            color: #495057;
            margin-bottom: 20px;
            line-height: 1.6;
            max-height: 120px;
            overflow: hidden;
            position: relative;
        }
        
        .message-content::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 30px;
          //  background: linear-gradient(to bottom, rgba(255,255,255,0), rgba(255,255,255,1));
        }
        
        .message-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }
        
        .btn-mark-read {
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 500;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .btn-mark-read.unread {
            background: #3498db;
        }
        
        .btn-mark-read.read {
            background: #6c757d;
            opacity: 0.7;
        }
        
        .btn-mark-read:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-mark-read.unread:hover {
            background: #2980b9;
        }
        
        .btn-delete {
            padding: 8px 16px;
            font-size: 14px;
            color: #6c757d;
            background: none;
            border: 1px solid #ced4da;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        
        .btn-delete:hover {
            color: #dc3545;
            border-color: #dc3545;
            background: #fff5f5;
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #6c757d;
        }
        
        .empty-state-text {
            font-size: 16px;
            font-weight: 500;
        }
        
        .empty-state-text:before {
            content: "⚠ ";
            font-size: 24px;
            display: block;
            margin-bottom: 10px;
            color: #dee2e6;
        }
        
        /* Pagination */
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        
        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0;
            gap: 5px;
        }
        
        .page-item {
            display: inline-block;
        }
        
        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #f8f9fa;
            color: #495057;
            text-decoration: none;
            transition: all 0.2s;
            font-weight: 500;
        }
        
        .page-link:hover {
            background: #e9ecef;
        }
        
        .page-item.active .page-link {
            background: #3498db;
            color: white;
        }
        
        .page-nav-prev:after {
            content: "◀";
        }
        
        .page-nav-next:after {
            content: "▶";
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .messages-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .messages-stat {
                width: 100%;
                justify-content: space-between;
            }
            
            .filters-section {
                flex-direction: column;
                align-items: stretch;
                gap: 15px;
            }
            
            .filter-controls, .search-box {
                width: 100%;
                max-width: none;
            }
        }
    </style>
    <script type="text/javascript">
        function markAsReadSuccess(buttonId) {
            var button = document.getElementById(buttonId);
            button.innerText = "Read";
            button.classList.remove("unread");
            button.classList.add("read");
            button.disabled = true;

            var messageCard = button.closest(".message-card");
            messageCard.classList.remove("unread");

            var statusBadge = messageCard.querySelector(".message-status");
            statusBadge.innerText = "Read";
            statusBadge.classList.remove("unread");

            // Update unread count
            var unreadCount = document.getElementById("unreadCount");
            if (unreadCount) {
                var currentCount = parseInt(unreadCount.innerText);
                if (currentCount > 0) {
                    unreadCount.innerText = currentCount - 1;
                }
            }
        }

        function confirmDelete() {
            return confirm("Are you sure you want to delete this message?");
        }

        function toggleSearch() {
            var searchBox = document.getElementById("searchBox");
            searchBox.classList.toggle("active");
            searchBox.focus();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="messages-container">
        <div class="dashboard-header">
            <h1 class="messages-header" style="border-bottom: 3px solid #4A90E2; ">
                Contact Messages
            </h1>
            <div class="messages-stat">
                <div class="stat-item">
                    <span class="stat-value"><asp:Literal ID="litTotalCount" runat="server">0</asp:Literal></span>
                    <span class="stat-label">Total</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="unreadCount"><asp:Literal ID="litUnreadCount" runat="server">0</asp:Literal></span>
                    <span class="stat-label">Unread</span>
                </div>
            </div>
        </div>
        
        <div class="filters-section">
            <div class="filter-controls">
                <span class="filter-label">Show:</span>
                <asp:DropDownList ID="ddlFilterStatus" runat="server" AutoPostBack="true" CssClass="styled-dropdown"
                    OnSelectedIndexChanged="ddlFilterStatus_SelectedIndexChanged">
                    <asp:ListItem Text="All Messages" Value=""></asp:ListItem>
                    <asp:ListItem Text="Unread Messages" Value="0" Selected></asp:ListItem>
                    <asp:ListItem Text="Read Messages" Value="1"></asp:ListItem>
                </asp:DropDownList>
                
                <asp:DropDownList ID="ddlSortOrder" runat="server" AutoPostBack="true" CssClass="styled-dropdown"
                    OnSelectedIndexChanged="ddlSortOrder_SelectedIndexChanged">
                    <asp:ListItem Text="Newest First" Value="newest" Selected></asp:ListItem>
                    <asp:ListItem Text="Oldest First" Value="oldest"></asp:ListItem>
                </asp:DropDownList>
            </div>
            
            <div class="search-box">
                <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" placeholder="Search by name or email..."
                    AutoPostBack="true" OnTextChanged="txtSearch_TextChanged"></asp:TextBox>
            </div>
        </div>
        
        <asp:Panel ID="pnlNoMessages" runat="server" CssClass="empty-state" Visible="false">
            <p class="empty-state-text">No messages found. Check back later!</p>
        </asp:Panel>
        
        <div class="messages-grid">
            <asp:Repeater ID="rptMessages" runat="server" OnItemCommand="rptMessages_ItemCommand">
                <ItemTemplate>
                    <div class='message-card <%# IIf(Eval("status"), "", "unread") %>'>
                        <div class="message-header">
                            <div class="message-info">
                                <div class="message-name">
                                    <%# Eval("c_name") %>
                                </div>
                                <div class="message-email">
                                    <%# Eval("email") %>
                                </div>
                                <div class="message-date">
                                    <%# FormatDateTime(Eval("submitted_at"), DateFormat.ShortDate)%>
                                </div>
                            </div>
                            <div class="message-status <%# IIf(Eval("status"), "", "unread") %>">
                                <%# IIf(Eval("status"), "Read", "Unread") %>
                            </div>
                        </div>
                        <div class="message-content">
                            <%# Eval("message") %>
                        </div>
                        <div class="message-actions">
                            <asp:Button ID="btnMarkRead" runat="server" Text='<%# IIf(Eval("status"), "Read", "Mark as Read") %>'
                                CssClass='<%# IIf(Eval("status"), "btn-mark-read read", "btn-mark-read unread") %>'
                                CommandArgument='<%# Eval("message_id") %>' CommandName="MarkRead"
                                Enabled='<%# Not(Eval("status")) %>' ClientIDMode="Static" />
                            
                            <asp:Button ID="btnDelete" runat="server" Text="Delete" CssClass="btn-delete"
                                CommandArgument='<%# Eval("message_id") %>' CommandName="DeleteMessage"
                                OnClientClick="return confirmDelete();" />
                        </div>
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
        
        <asp:Panel ID="pnlPagination" runat="server" CssClass="pagination-container">
            <ul class="pagination">
                <li class="page-item">
                    <asp:LinkButton ID="lnkPrevious" runat="server" CssClass="page-link page-nav-prev" 
                        OnClick="lnkPrevious_Click"></asp:LinkButton>
                </li>
                
                <asp:Repeater ID="rptPagination" runat="server" OnItemCommand="rptPagination_ItemCommand">
                    <ItemTemplate>
                        <li class='page-item <%# IIf(Container.DataItem = ViewState("CurrentPage"), "active", "") %>'>
                            <asp:LinkButton ID="lnkPage" runat="server" CssClass="page-link"
                                CommandArgument='<%# Container.DataItem %>' CommandName="ChangePage">
                                <%# Container.DataItem %>
                            </asp:LinkButton>
                        </li>
                    </ItemTemplate>
                </asp:Repeater>
                
                <li class="page-item">
                    <asp:LinkButton ID="lnkNext" runat="server" CssClass="page-link page-nav-next"
                        OnClick="lnkNext_Click"></asp:LinkButton>
                </li>
            </ul>
        </asp:Panel>
    </div>
</asp:Content>