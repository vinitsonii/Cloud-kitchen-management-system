﻿<%@ Page Title="" Language="vb" AutoEventWireup="false" MasterPageFile="~/Admin/Admin.Master" CodeBehind="ManageCC1.aspx.vb" Inherits="Cloud_Kitchen.WebForm9" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">


 <style type="text/css">
 .update-panel {
    animation: fadeIn 0.8s ease-out, slideDown 0.5s ease-out;
    position: fixed;
    top: 50%;
    left: 60%;
    transform: translate(-50%, -50%);
    padding: 30px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    max-width: 600px;
    width: 80%;
    z-index: 2050;
    max-height: 80vh;
    overflow-y: auto;
}

h3, .food-heading, .grid-manage h2 {
    font-family: 'Poppins', sans-serif;
    text-align: center;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 0.5px;
}

h3 {
    font-size: 1.6rem;
    color: #1a73e8;
    margin-bottom: 22px;
    position: relative;
    padding-bottom: 10px;
}

h3:after {
    content: '';
    position: absolute;
    width: 60px;
    height: 3px;
    background: linear-gradient(90deg, #1a73e8, #6ab7ff);
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 3px;
}

.food-heading {
    font-size: 2rem;
    background: -webkit-linear-gradient(45deg, #1a73e8, #6ab7ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 30px;
    position: relative;
    display: inline-block;
}

.food-heading:after {
    content: '';
    position: absolute;
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, #1a73e8, #6ab7ff);
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 4px;
}

.grid-manage h2 {
    font-size: 1.4rem;
    color: #1a73e8;
    margin-top: 35px;
    margin-bottom: 15px;
    position: relative;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 22px;
}

.form-group label {
    font-size: 0.9rem;
    font-weight: 600;
    color: #424242;
    letter-spacing: 0.3px;
}

input[type="text"], select {
    padding: 12px 16px;
    font-size: 0.95rem;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    background: #f8f9fa;
    box-shadow: inset 1px 1px 4px rgba(0, 0, 0, 0.05);
    transition: all 0.3s;
}

input[type="text"]:focus, select:focus {
    border-color: #1a73e8;
    outline: none;
    box-shadow: 0 0 0 3px rgba(26, 115, 232, 0.2);
    background: #fff;
}

.form-actions {
    display: flex;
    gap: 15px;
    margin-top: 28px;
    justify-content: center;
}

.btn-save, .btn-cancel {
    color: white;
    padding: 10px 24px;
    font-size: 0.95rem;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-save {
    background: linear-gradient(135deg, #1a73e8, #0d47a1);
}

.btn-save:hover {
    background: linear-gradient(135deg, #0d47a1, #0a3880);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(26, 115, 232, 0.3);
}

.btn-cancel {
    background: linear-gradient(135deg, #f44336, #d32f2f);
}

.btn-cancel:hover {
    background: linear-gradient(135deg, #d32f2f, #b71c1c);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(244, 67, 54, 0.3);
}

.table-bordered {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 25px;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
    border-radius: 10px;
    overflow: hidden;
    background: white;
}

.table-bordered thead {
    background: linear-gradient(135deg, #1a73e8, #0d47a1);
    color: white;
    font-weight: bold;
}

.table-bordered th, .table-bordered td {
    padding: 12px 14px;
    border: none;
    border-bottom: 1px solid #eaeaea;
    text-align: left;
    font-size: 0.95rem;
}

.table-bordered th {
    letter-spacing: 0.5px;
    text-transform: uppercase;
    font-size: 0.85rem;
}

.table-bordered tbody tr:last-child td {
    border-bottom: none;
}

.table-bordered tbody tr {
    transition: all 0.2s ease;
}

.table-bordered tbody tr:nth-child(even) {
    background: #f8fafd;
}

.table-bordered tbody tr:hover {
    background: #e8f0fe;
    cursor: pointer;
    transform: translateY(-1px);
    box-shadow: 0 2px 10px rgba(26, 115, 232, 0.15);
}

.lblmsg {
    color: #f44336;
    text-align: center;
    font-size: 0.9rem;
    font-weight: 500;
    padding: 5px 0;
}

.message {
    text-align: center;
    font-size: 0.9rem;
    padding: 12px;
    border-radius: 8px;
    margin-top: 15px;
    display: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.message.success {
    background-color: #e8f5e9;
    color: #2e7d32;
    border-left: 4px solid #4caf50;
}

.message.error {
    background-color: #fdecea;
    color: #c62828;
    border-left: 4px solid #f44336;
}

@keyframes fadeIn {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

@keyframes slideDown {
    0% { transform: translate(-50%, -60%); }
    100% { transform: translate(-50%, -50%); }
}

.card-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 30px;
    height: 800px;
    margin: 20px auto;
    border-radius: 16px;
    background: #fff;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1), 0 5px 15px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    overflow: hidden;
    position: relative;
}

.card-container:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 5px;
    background: linear-gradient(90deg, #1a73e8, #6ab7ff);
}

.content {
    height: 90%;
}

.button-wrapper {
    display: flex;
    gap: 30px;
    justify-content: center;
    width: 1700px;
    height: 80%;
    margin-bottom: 30px;
}

.button-box {
    background: white;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
    display: flex;
    flex-direction: column;
    align-items: center;
    transition: all 0.4s ease;
    width: 600px;
    height: 600px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
    border: 1px solid #f0f0f0;
}

.button-box:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
   // background: linear-gradient(90deg, #1a73e8, #6ab7ff);
    opacity: 0;
    transition: opacity 0.4s ease;
}

.button-box:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(26, 115, 232, 0.15);
}

.button-box:hover:before {
    opacity: 1;
}

.image-button {
    width: 110px;
    height: 110px;
    transition: all 0.4s ease-in-out;
    filter: drop-shadow(0 5px 15px rgba(0, 0, 0, 0.1));
}

.button-text {
    font-size: 16px;
    font-weight: 700;
    color: #1a73e8;
    text-align: center;
    margin-top: 15px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

@media (max-width: 992px) {
    .button-wrapper {
        flex-direction: column;
        gap: 25px;
    }
    
    .button-box {
        height: auto;
        min-height: 400px;
    }
    
    .card-container {
        height: auto;
        min-height: 1000px;
    }
}

@media (max-width: 768px) {
    .update-panel, .card-container {
        width: 95%;
        padding: 20px;
    }

    .form-actions {
        flex-direction: column;
        gap: 10px;
    }
    
    .food-heading {
        font-size: 1.6rem;
    }
    
    h3 {
        font-size: 1.4rem;
    }
    
    .btn-save, .btn-cancel {
        width: 100%;
    }
}

.button-box {
    padding: 25px;
    max-height: 550px; 
    overflow-y: auto;
    border-radius: 16px;
    background: #fff;
}

/* Scrollbar styling */
.button-box::-webkit-scrollbar {
    width: 8px;
}

.button-box::-webkit-scrollbar-track {
    background: #f0f2f5;
    border-radius: 10px;
}

.button-box::-webkit-scrollbar-thumb {
    background: rgba(26, 115, 232, 0.6);
    border-radius: 10px;
    border: 2px solid #f0f2f5;
}

.button-box::-webkit-scrollbar-thumb:hover {
    background: rgba(26, 115, 232, 0.8);
}

.scrollable-panel {
    padding-top: 40px;
}

/* Form validation styling */
.form-control {
    position: relative;
}

[id*="RegularExpressionValidator"] {
    font-size: 0.8rem;
    padding: 5px 0;
    transition: all 0.3s ease;
}

/* Button styles for CRUD operations in tables */
.table-bordered .btn-save, .table-bordered .btn-cancel {
    padding: 6px 12px;
    font-size: 0.85rem;
    margin: 0 3px;
    min-width: 70px;
}

/* Add subtle animation for form actions */
.form-actions .btn-save, .form-actions .btn-cancel {
    position: relative;
    overflow: hidden;
}

.form-actions .btn-save:after, .form-actions .btn-cancel:after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 5px;
    height: 5px;
    background: rgba(255, 255, 255, 0.5);
    opacity: 0;
    border-radius: 100%;
    transform: scale(1, 1) translate(-50%);
    transform-origin: 50% 50%;
}

.form-actions .btn-save:focus:after, .form-actions .btn-cancel:focus:after {
    animation: ripple 1s ease-out;
}

@keyframes ripple {
    0% {
        transform: scale(0, 0);
        opacity: 0.5;
    }
    100% {
        transform: scale(20, 20);
        opacity: 0;
    }
}


.scrollable-panel {
    padding-top: 40px;
    width: -webkit-fill-available;
}
 </style>


</asp:Content>



<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">


<asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
    

<asp:UpdatePanel ID="UpdatePanel4" runat="server">
    <ContentTemplate>
        <div class="card-container">
            <h2 class="food-heading">Manage Food Items</h2>
            <div class="button-wrapper">
                <div class="button-box">
                   <%-- <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/icons/users1.png" CssClass="image-button" CausesValidation="false" ToolTip="Category Management" />
                   <p class="button-text">Manage Categories</p> --%>
                    <asp:Panel ID="up1" runat="server" CssClass="scrollable-panel">
                <h3>Manage Category</h3>

                <asp:HiddenField ID="hfCategoryId" runat="server" />

                <div class="form-group">
                    <label for="txtCategoryName">Category Name</label>
                    <asp:TextBox ID="txtCategoryName" runat="server" CssClass="form-control" placeholder="Enter category name"></asp:TextBox>
                    <asp:RegularExpressionValidator ID="revcatName" runat="server" ControlToValidate="txtCategoryName"
                        ErrorMessage="Only alphabets and spaces are allowed." ValidationGroup="frm1" ValidationExpression="^[A-Za-z ]+$"
                        Display="Dynamic" ForeColor="Red" />
                </div>

                <div class="form-group">
                    <label for="ddlCategoryStatus">Category Status</label>
                    <asp:DropDownList ID="ddlCategoryStatus" runat="server" CssClass="form-control">
                        <asp:ListItem Text="Active" Value="1"></asp:ListItem>
                        <asp:ListItem Text="Inactive" Value="0"></asp:ListItem>
                    </asp:DropDownList>
                </div>

                <div class="form-group lblmsg">
                    <asp:Label ID="lblmsg" runat="server" ForeColor="Red"></asp:Label>
                </div>

                <div class="form-actions">
                    <asp:Button ID="btnSave" runat="server" Text="Save" CssClass="btn-save" OnClick="btnSave_Click" ValidationGroup="frm1"/>
                    <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="btn-save" OnClick="btnUpdate_Click" Visible="False" C ValidationGroup="frm1"/>
                    <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-cancel" OnClick="btnCancel_Click" CausesValidation="false" />
                </div>

                <div class="grid-manage">
                    <h2>Select Category To Edit</h2>
                    <asp:Repeater ID="rptcat" runat="server" OnItemCommand="rptcat_ItemCommand" >
                        <HeaderTemplate>

                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Category Name</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td><%# Eval("category_name") %></td>
                                <td><%# Eval("category_status") %></td>
                                <td style="display:flex;">
                                    <asp:Button ID="btnEdit" runat="server" CssClass="btn-save" CommandName="EditCategory" CommandArgument='<%# Eval("category_id") %>' Text="Edit" CausesValidation="false" />
                                    <asp:Button ID="btnDelete" runat="server" CssClass="btn-cancel" CommandName="DeleteCategory" CommandArgument='<%# Eval("category_id") %>' Text="Delete" CausesValidation="false" />
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                                </tbody>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                    <br />
                </div>
            </asp:Panel>
                </div>
                <div class="button-box">
                    <%--<asp:ImageButton ID="ImageButton2" runat="server" ImageUrl="~/icons/edit.png" CssClass="image-button" CausesValidation="false" ToolTip="Cuisine Item" />
                    <p class="button-text">Manage Cuisines</p>
                    --%><asp:Panel ID="up2" runat="server" CssClass="scrollable-panel" >
                <h3>Manage Cuisine</h3>

                <asp:HiddenField ID="hfCuisineId" runat="server" />

                <div class="form-group">
                    <label for="txtCuisineName">Cuisine Name</label>
                    <asp:TextBox ID="txtCuisineName" runat="server" CssClass="form-control" placeholder="Enter Cuisine name"></asp:TextBox>
                    <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtCuisineName"
                        ErrorMessage="Only alphabets and spaces are allowed." ValidationGroup="frm2" ValidationExpression="^[A-Za-z ]+$"
                        Display="Dynamic" ForeColor="Red" />
                </div>

                <div class="form-group">
                    <label for="ddlCuisineStatus">Cuisine Status</label>
                    <asp:DropDownList ID="ddlCuisineStatus" runat="server" CssClass="form-control">
                        <asp:ListItem Text="Active" Value="1"></asp:ListItem>
                        <asp:ListItem Text="Inactive" Value="0"></asp:ListItem>
                    </asp:DropDownList>
                </div>

                <div class="form-group lblmsg">
                    <asp:Label ID="lblmsg2" runat="server" ForeColor="Red"></asp:Label>
                </div>

                <div class="form-actions">
                    <asp:Button ID="btnSave2" runat="server" Text="Save" CssClass="btn-save" ValidationGroup="frm2"  />
                    <asp:Button ID="btnUpdate2" runat="server" Text="Update" CssClass="btn-save" ValidationGroup="frm2" Visible="False" />
                    <asp:Button ID="btnCancel2" runat="server" Text="Cancel" CssClass="btn-cancel" CausesValidation="false" />
                </div>

                <div class="grid-manage">
                    <h2>Select Cuisine To Edit</h2>
                    <asp:Repeater ID="rptcuisine" runat="server" OnItemCommand="rptcuisine_ItemCommand">
                        <HeaderTemplate>
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Cuisine Name</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td><%# Eval("cuisine_name")%></td>
                                <td><%# Eval("cuisine_status")%></td>
                                <td style="display:flex;">
                                    <asp:Button ID="btnEdit2" runat="server" CommandName="EditCuisine" CommandArgument='<%# Eval("cuisine_id") %>' Text="Edit" CssClass="btn-save" CausesValidation="false"/>
                                    <asp:Button ID="btnDelete2" runat="server" CommandName="DeleteCuisineName" CommandArgument='<%# Eval("cuisine_id") %>' Text="Delete" CssClass="btn-cancel" CausesValidation="false"/>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                                </tbody>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                </div>
            </asp:Panel>
                    <br />
                </div>
            </div>
        </div>
    </ContentTemplate>
</asp:UpdatePanel>






<%--    
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            
        </ContentTemplate>
    </asp:UpdatePanel>

<asp:UpdatePanel ID="UpdatePanel2" runat="server">
        <ContentTemplate>
            
        </ContentTemplate>
    </asp:UpdatePanel>

--%>

</asp:Content>
