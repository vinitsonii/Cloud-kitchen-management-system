﻿<%@ Page Title="Register" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master" CodeBehind="Register.aspx.vb" Inherits="Cloud_Kitchen.WebForm4" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        :root {
            --primary: #4F7E76;
            --primary-dark: #3a5f59;
            --secondary: #f4f4f4;
            --background: #f9fafc;
            --text: #333;
            --accent: #ff6b4a;
            --accent-hover: #e35a3c;
            --form-bg: #ffffff;
            --form-border: #e8e8e8;
            --form-shadow: rgba(0, 0, 0, 0.08);
            --input-border: #dbe0e6;
            --input-focus: rgba(79, 126, 118, 0.25);
            --success: #4caf50;
            --success-dark: #3d8b40;
            --primary-btn: #007bff;
            --primary-btn-hover: #0056b3;
        }

        body {
            font-family: 'Poppins', 'Open Sans', sans-serif;
            background: linear-gradient(145deg, #f0f4f8, #ffffff);
            margin: 0;
            color: var(--text);
            line-height: 1.6;
        }

        .registration-container {
            display: flex;
            min-height: 80vh;
            max-width: 1600px;
            margin: 0 auto;
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.1);
        }

        .registration-image-section {
            flex: 1.2;
            position: relative;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.65)), 
                        url('../Images/lb7.jpeg') center/cover no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: #fff;
            padding: 2rem;
            overflow: hidden;
        }

        .registration-image-section::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(79, 126, 118, 0.3), rgba(0, 0, 0, 0.4));
            z-index: 1;
        }

        .registration-image-section > div {
            position: relative;
            z-index: 2;
            max-width: 500px;
            padding: 2rem;
            border-radius: 20px;
            backdrop-filter: blur(8px);
            background-color: rgba(0, 0, 0, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .registration-image-section h2 {
            font-size: 2.6rem;
            font-weight: 700;
            margin-bottom: 1rem;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            letter-spacing: 0.5px;
        }

        .registration-image-section p {
            font-size: 1.25rem;
            font-weight: 300;
            line-height: 1.6;
            text-shadow: 0 1px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 0;
        }

        .registration-form-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 2rem;
            background-color: var(--form-bg);
            overflow-y: auto;
        }

        .form-card {
            width: 100%;
            max-width: 450px;
            background: var(--form-bg);
            padding: 2.5rem;
            border-radius: 16px;
            border: 1px solid var(--form-border);
            box-shadow: 0 15px 35px var(--form-shadow);
            animation: fadeInUp 0.8s ease-out;
            margin: 1rem 0;
        }

        .form-card h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: var(--primary);
            font-size: 2rem;
            font-weight: 600;
        }

        .form-card hr {
            border: none;
            height: 3px;
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            margin: 1.5rem 0;
            border-radius: 2px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            display: block;
            color: #3a4a5b;
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #fafbfc;
            box-sizing: border-box;
        }

        .form-group input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 4px var(--input-focus);
            background-color: #fff;
        }

        .phone-group {
            display: flex;
            gap: 10px;
        }

        .phone-group .country-code {
            width: 70px;
            text-align: center;
            background-color: #f2f4f6;
            font-weight: 500;
            color: #455a64;
        }

        .phone-group input:not(.country-code) {
            flex: 1;
        }

        .password-input {
            width: 100% !important;
            padding: 0.75rem 1rem;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            font-size: 1rem;
            background-color: #fafbfc;
            box-sizing: border-box;
        }

        .password-container {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 1.1rem;
            color: #5a6a7a;
            z-index: 10;
            background: none;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.25rem;
        }

        .toggle-password:hover {
            color: var(--primary);
        }

        .register-btn {
            width: 100%;
            padding: 0.9rem;
            font-size: 1.1rem;
            font-weight: 600;
            color: white;
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(79, 126, 118, 0.3);
        }

        .register-btn:hover {
            background: linear-gradient(to right, var(--primary-dark), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(79, 126, 118, 0.4);
        }

        .register-btn:active {
            transform: translateY(0);
        }

        .toggle-link {
            margin-top: 1.5rem;
            text-align: center;
            font-size: 0.95rem;
        }

        .toggle-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .toggle-link a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        /* Modal Styles */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
            z-index: 2000;
            display: none;
            animation: fadeIn 0.3s ease-out;
        }

        .update-panel {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 0;
            background: transparent;
            border: none;
            box-shadow: none;
            max-width: 500px;
            width: 90%;
            z-index: 3000;
            max-height: 90vh;
            overflow-y: auto;
        }

        .success-panel {
            background-color: var(--form-bg);
            border-radius: 16px;
            padding: 2.5rem;
            text-align: center;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.2);
            border: 1px solid var(--form-border);
        }

        .success-icon {
            width: 80px;
            height: 80px;
            margin-bottom: 1.5rem;
            animation: bounce 1s ease infinite alternate;
        }

        .success-title {
            color: var(--success);
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .success-message {
            color: var(--text);
            font-size: 1.1rem;
            margin-bottom: 1rem;
            font-weight: 500;
        }

        .next-steps {
            color: #555;
            font-size: 1rem;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .button-group {
            margin-top: 1.5rem;
        }

        .btn-primary {
            background: linear-gradient(to right, var(--primary-btn), #0062cc);
            color: white;
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #0069d9, #0056b3);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 123, 255, 0.4);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .btn-secondary {
            background: linear-gradient(to right, var(--success), var(--success-dark));
            color: white;
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(76, 175, 80, 0.3);
        }

        .btn-secondary:hover {
            background: linear-gradient(to right, #43a047, #388e3c);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(76, 175, 80, 0.4);
        }

        .btn-secondary:active {
            transform: translateY(0);
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes bounce {
            from {
                transform: translateY(0);
            }
            to {
                transform: translateY(-10px);
            }
        }

        /* Responsive design */
        @media (max-width: 1200px) {
            .registration-image-section h2 {
                font-size: 2.5rem;
            }
            
            .registration-image-section p {
                font-size: 1.1rem;
            }
        }

        @media (max-width: 992px) {
            .registration-container {
                flex-direction: column;
                max-height: none;
            }

            .registration-image-section {
                height: 300px;
                flex: none;
            }
            
            .registration-form-section {
                padding: 2rem 1.5rem;
            }
            
            .form-card {
                padding: 2rem;
                max-width: 600px;
            }
            
            .update-panel {
                width: 95%;
                max-width: 450px;
            }
        }

        @media (max-width: 768px) {
            .registration-image-section {
                height: 250px;
            }
            
            .registration-image-section h2 {
                font-size: 2.2rem;
            }
            
            .registration-image-section > div {
                padding: 1.5rem;
            }
            
            .form-card {
                padding: 1.5rem;
            }
            
            .success-panel {
                padding: 1.8rem;
            }
            
            .success-title {
                font-size: 1.6rem;
            }
        }

        @media (max-width: 480px) {
            .registration-image-section {
                height: 220px;
            }
            
            .registration-image-section h2 {
                font-size: 1.8rem;
            }
            
            .registration-image-section p {
                font-size: 0.95rem;
            }
            
            .registration-image-section > div {
                padding: 1.2rem;
            }
            
            .form-card {
                padding: 1.2rem;
                border-radius: 12px;
            }
            
            .form-card h2 {
                font-size: 1.6rem;
            }
            
            .success-panel {
                padding: 1.5rem;
            }
            
            .success-icon {
                width: 60px;
                height: 60px;
            }
            
            .btn-primary, .btn-secondary {
                padding: 0.7rem 1.2rem;
                font-size: 0.9rem;
            }
        }
    </style>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById('<%= txtPassword.ClientID %>');
            var eyeIcon = document.getElementById("eyeIcon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.innerHTML = "🙈"; // Change icon to hide
            } else {
                passwordField.type = "password";
                eyeIcon.innerHTML = "👁️"; // Change icon to show
            }
        }
    </script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="registration-container">
        <div class="registration-image-section">
            <div>
                <h2>Join Our Cloud Kitchen</h2>
                <p>Create an account today and discover a world of delicious, chef-crafted meals delivered right to your doorstep.</p>
            </div>
        </div>
        
        <asp:ScriptManager ID="ScriptManager2" runat="server">
        </asp:ScriptManager>

        <div id="overlay" class="overlay" runat="server"></div> 
        <asp:Panel ID="pnlmsg" runat="server" CssClass="update-panel success-panel" Visible="false">
            <div class="message-box">
                <img src="../icons/complete.png" alt="Success" class="success-icon" />
                <h2 class="success-title">Registration Successful! 🎉</h2>
                <asp:Label ID="lblmsg1" runat="server" CssClass="success-message"></asp:Label>
                <p class="next-steps">
                    Thank you for joining our Cloud Kitchen community! Your account has been created successfully. You can now log in to explore our menu and place your first order.
                </p>
                <div class="button-group">
                    <asp:Button ID="btnLogin" runat="server" Text="Login Now" CssClass="btn-primary"
                        CausesValidation="False" PostBackUrl="~/Customers/Login.aspx" />
                </div>
            </div>
        </asp:Panel>

        <div class="registration-form-section">
            <div class="form-card">
                <h2>Create Account</h2>
                
                <hr />
                <div class="form-group">   
                    <asp:Label ID="lblmsg" runat="server" Text="" ForeColor="#E35A3C"></asp:Label>
                </div>
                <div class="form-group">
                    <label for="txtFullName">Full Name</label>
                    <asp:TextBox ID="txtFullName" runat="server" placeholder="Enter your full name"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvFullName" runat="server" ControlToValidate="txtFullName" ErrorMessage="Full name is required" Display="Dynamic" ForeColor="#E35A3C" />
                </div>
                
                <div class="form-group">
                    <label for="txtEmail">Email Address</label>
                    <asp:TextBox ID="txtEmail" runat="server" placeholder="Enter your email address" AutoPostBack="true"></asp:TextBox>
                    <asp:RequiredFieldValidator ID="rfvEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="Email is required" Display="Dynamic" ForeColor="#E35A3C" />
                    <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="Invalid email format" ValidationExpression="^\S+@\S+\.\S+$" Display="Dynamic" ForeColor="#E35A3C" />
                    <asp:Label ID="lblEmailError" runat="server" ForeColor="#E35A3C"></asp:Label>
                </div>
                
                <div class="form-group">
                    <label for="txtPhone">Mobile Number</label>
                    <div class="phone-group">
                        <asp:TextBox ID="txtCountryCode" runat="server" Text="+91" ReadOnly="true" CssClass="country-code"></asp:TextBox>
                        <asp:TextBox ID="txtPhone" runat="server" placeholder="Enter your mobile number" AutoPostBack="true" MaxLength="10" TextMode="number"></asp:TextBox>
                    </div>
                    <asp:RequiredFieldValidator ID="rfvPhone" runat="server" ControlToValidate="txtPhone" ErrorMessage="Mobile number is required" Display="Dynamic" ForeColor="#E35A3C" />
                    <asp:Label ID="lblPhoneError" runat="server" ForeColor="#E35A3C"></asp:Label>
                </div>
                
                <div class="form-group">
                    <label for="txtPassword">Password</label>
                    <div class="password-container" style="position: relative;">
                        <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" placeholder="Create a strong password" CssClass="password-input"></asp:TextBox>
                        <button type="button" class="toggle-password" onclick="togglePassword()" id="eyeIcon">👁️</button>
                    </div>
                    <asp:RequiredFieldValidator ID="rfvPassword" runat="server" ControlToValidate="txtPassword" ErrorMessage="Password is required" Display="Dynamic" ForeColor="#E35A3C" />
                    <asp:RegularExpressionValidator ID="revPassword" runat="server" ControlToValidate="txtPassword" 
                        ErrorMessage="Password must be at least 6 characters, include 1 uppercase, 1 lowercase, 1 digit, and 1 special character." 
                        ValidationExpression="^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%#*?&])[A-Za-z\d@$!%#*?&]{6,}$" Display="Dynamic" ForeColor="#E35A3C" />
                </div>

                <asp:Button ID="btnRegister" runat="server" Text="Create Account" 
                    CssClass="register-btn" CausesValidation="False" AutoPostBack="true"/>
                <div class="toggle-link">
                    <a href="Login.aspx">Already have an account? Sign in</a>
                </div>
            </div>
        </div>
    </div>
</asp:Content>