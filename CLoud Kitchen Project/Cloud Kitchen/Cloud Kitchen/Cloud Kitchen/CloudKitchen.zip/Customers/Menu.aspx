﻿<%@ Page Title="" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master"
    CodeBehind="Menu.aspx.vb" Inherits="Cloud_Kitchen.Menu" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        /* Search & Filter Section */
        /* 🌟 Hero Section */
        .hero-section
        {
            position: relative;
            width: 100%;
            height: 450px;
            background: url('../Images/menubg.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            font-family: 'Arial' , sans-serif;
            z-index:1;
        }
        
        .hero-overlay
        {
            background: rgba(0, 0, 0, 0.6);
            padding: 25px;
            border-radius: 12px;
        }
        
        .hero-section h1
        {
            font-size: 40px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.6);
        }
        
        .hero-section p
        {
            font-size: 20px;
            margin-bottom: 15px;
            color: #f2f2f2;
        }
        
        /* 🌿 Buttons */
        .explore-btn, .order-btn
        {
            background: #4F7E76;
            padding: 12px 22px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 10px rgba(79, 126, 118, 0.3);
        }
        
        .explore-btn:hover, .order-btn:hover
        {
            background: #3d635d;
            box-shadow: 0 6px 15px rgba(79, 126, 118, 0.4);
        }
        
        /* 🎯 Search & Filter Section */
        .menu-filters
        {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin: 30px auto;
            max-width: 1000px;
            //background-color:#fff;
           backdrop-filter:blur(10px);
            background: rgba(0, 0, 0, 0.6);
            margin-top:-50px;
            position: relative;
            z-index:1000;
            padding:20px;
            border-radius:20px;
        }
        
        /* 🌟 Input Fields */
        .filter-box
        {
            flex: 1;
            padding: 12px;
            border: 2px solid #4F7E76;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f9f9f9;
            font-weight: bold;
            color: #333;
        }
        
        .filter-box:focus
        {
            border-color: #3d635d;
            outline: none;
            box-shadow: 0 0 10px rgba(79, 126, 118, 0.5);
        }
        
        /* 🎨 Dropdown Styling */
        .filter-box select
        {
            padding: 10px;
            background: white;
            border: none;
            font-size: 16px;
            font-weight: bold;
        }
        
        /* 🥗 Menu Grid */
        .menu-grid
        {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* 🍔 Menu Card */
        .menu-card
        {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }
        
        .menu-card:hover
        {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }
        
        /* 📸 Menu Image */
        .menu-card img
        {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        
        .menu-card:hover img
        {
            transform: scale(1.05);
        }
        
        /* 🍕 Menu Details */
        .menu-card h3
        {
            font-size: 22px;
            margin: 15px 0;
            color: #333;
            font-weight: bold;
        }
        
        .menu-card p
        {
            font-size: 15px;
            color: #555;
        }
        
        /* 💰 Price */
        .menu-price
        {
            font-size: 22px;
            font-weight: bold;
            color: #4F7E76;
            margin: 10px 0;
        }
        
        /* 🏷 Category & Cuisine Tags */
        .menu-tags
        {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 8px;
        }
        
        .tag
        {
            font-size: 13px;
            padding: 4px 12px;
            border-radius: 15px;
            font-weight: bold;
            color: white;
        }
        
        .category-tag
        {
            background-color: #0078d7;
        }
        
        .cuisine-tag
        {
            background-color: #27ae60;
        }
        
        
        .not-available-label
        {
            background: red;
            color: white;
            font-size: 14px;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="hero-overlay">
            <h1>
                🍽️ Delicious Food, Delivered Fast! 🚀</h1>
            <p>
                Order your favorite meals fresh & hot. Enjoy restaurant-quality food at your doorstep!</p>
            <%--<asp:Button ID="btnExplore" runat="server" CssClass="explore-btn" Text="Explore Menu" PostBackUrl="~/Menu.aspx" />--%>
        </div>
    </div>
    <!-- Search & Filter Section -->
    <div class="menu-filters">
        <asp:TextBox ID="txtSearch" runat="server" CssClass="filter-box" placeholder="🔍 Search food..."
            AutoPostBack="true" OnTextChanged="FilterMenu"></asp:TextBox>
        <asp:DropDownList ID="ddlCategory" runat="server" CssClass="filter-box" AutoPostBack="true"
            OnSelectedIndexChanged="FilterMenu">
            <asp:ListItem Text="🍽️ All Categories" Value="0"></asp:ListItem>
        </asp:DropDownList>
        <asp:DropDownList ID="ddlCuisine" runat="server" CssClass="filter-box" AutoPostBack="true"
            OnSelectedIndexChanged="FilterMenu">
            <asp:ListItem Text="🌍 All Cuisines" Value="0"></asp:ListItem>
        </asp:DropDownList>
    </div>
    <!-- Menu Display Section -->
    <div class="menu-grid">
        <asp:Repeater ID="rptMenuItems" runat="server">
            <ItemTemplate>
                <div class="menu-card">
                    <img src='<%# Eval("m_image_url") %>' alt="Menu Image">
                    <h3>
                        <%# Eval("m_name") %></h3>
                    <p>
                        <%# Eval("m_description") %></p>
                    <!-- Category & Cuisine Badges -->
                    <div class="menu-tags">
                        <span class="tag category-tag">
                            <%# Eval("category_name") %></span> <span class="tag cuisine-tag">
                                <%# Eval("cuisine_name") %></span>
                    </div>
                    <p class="menu-price">
                        ₹<%# Eval("m_final_price") %></p>
                    <asp:Panel ID="Panel1" runat="server" CssClass="not-available-label" Visible='<%# Not Convert.ToBoolean(Eval("m_availability")) %>'>
                        ❌ Not Available
                    </asp:Panel>
                    <asp:Button ID="btnOrderNow" runat="server" CssClass="order-btn" Text="Order Now"
                        CommandArgument='<%# Eval("m_id") %>' Visible='<%# Convert.ToBoolean(Eval("m_availability")) %>'
                        OnCommand="OrderNow_Click" />
                </div>
            </ItemTemplate>
        </asp:Repeater>
<asp:Panel ID="pnlempty" runat="server" Visible="false">
    <div class="menu-empty-container" style="
        max-width: 600px;
        margin: 60px auto;
        padding: 45px 30px;
        text-align: center;
        background: linear-gradient(135deg, #f5faff, #eaf3ff);
        border-radius: 18px;
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.06);
        font-family: 'Segoe UI', sans-serif;
    ">
        <h2 style="
            font-size: 28px;
            color: #2c3e50;
            margin-bottom: 12px;
        ">
            We're sorry, nothing's available right now 🙁
        </h2>

        <img src="../icons/em5.png" width="120" alt="No Items Found" style="
            margin-bottom: 25px;
            animation: float 4s ease-in-out infinite;
            filter: drop-shadow(2px 4px 8px rgba(0,0,0,0.1));
        " />

        <p style="
            font-size: 18px;
            color: #555;
            margin-bottom: 10px;
        ">
            It looks like we couldn't find any menu items that match your search or selected filters.
        </p>

        <p style="
            font-size: 16px;
            color: #777;
            margin-bottom: 25px;
        ">
            Please feel free to adjust your selection or check back shortly. We're always cooking up something new for you! 🍳😊
        </p>

        <a href="menu.aspx" style="
            display: inline-block;
            padding: 12px 26px;
            background-color: #007BFF;
            color: #fff;
            border-radius: 10px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            box-shadow: 0 6px 16px rgba(0,123,255,0.2);
            transition: background-color 0.3s ease;
        " onmouseover="this.style.backgroundColor='#0056b3'" onmouseout="this.style.backgroundColor='#007BFF'">
            🔁 View All Menu Items
        </a>
    </div>

    <style>
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
        }

        @media (max-width: 600px) {
            .menu-empty-container {
                padding: 30px 20px;
            }
            .menu-empty-container h2 {
                font-size: 24px;
            }
        }
    </style>
</asp:Panel>

    </div>
    <br />
    <br />
    <br />
</asp:Content>
