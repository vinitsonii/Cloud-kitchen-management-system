﻿<%@ Page Title="Home" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master"
    CodeBehind="Home.aspx.vb" Inherits="Cloud_Kitchen.WebForm1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        
        :root
        {
            --pc: #4F7E76; 
            --sc: #f4f4f4; 
            --bg: #fafafa; 
            --txt: #333; 
            --btn: #ff5722; 
            --btn-hov: #e64a19; 
        }
        html {
  scroll-behavior: smooth;
}

        
        body
        {
            font-family: 'Open Sans' , sans-serif;
            background-color: var(--bg);
            margin: 0;
            color: var(--txt);
            animation: fadeInBody 1s ease-in;
        }

        @keyframes fadeInBody {
            from {
                opacity: 0;
                background:#000; 
            }
            to {
                opacity: 1;
            }
        } 
        
        
        .hero
        {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('../Images/lb6.jpeg') center/cover no-repeat;
            height: 100vh;
            color: white;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 0 20px;
        }
        
        .hero h1
        {
            font-size: 2.9rem;
            text-transform: uppercase;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .hero p
        {
            font-size: 1.2rem;
            margin-bottom: 30px;
            max-width: 600px;
        }
        
        .hero .btn
        {
            padding: 12px 30px;
            background-color: var(--btn);
            color: white;
            font-size: 1.2rem;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
        
        .hero .btn:hover
        {
            background-color: var(--btn-hov);
            transform: scale(1.1);
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        .about-slider-container
        {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            background-color: var(--bg);
            margin: 40px auto;
            gap: 10px;
            padding: 30px;
        }
        
        .about-section
        {
            flex: 1;
            max-width: 45%;
            padding: 40px;
            text-align: left;
        }
        
        .about-section h2
        {
            font-size: 2.5rem;
            color: var(--pc);
            margin-bottom: 10px;
            position: relative;
            font-weight:bold;
        }
        
        .about-section h2::after
        {
            content: '';
            width: 70px;
            height: 4px;
            background-color: #ff9f43;
            display: block;
            margin: 10px auto 0;
        }
        
        .about-section p
        {
            font-size: 1.1rem;
            color: var(--txt);
            line-height: 1.8;
        }
        
        .slider-section
        {
            flex: 1;
            max-width: 50%;
            overflow: hidden;
            border-radius: 10px;
        }
        
        .img-slide
        {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
            cursor:pointer;
        }
        
        .slide-img
        {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }
        
        .slide-img.active
        {
            opacity: 1;
        }
        
        .feat
        {
            padding: 80px 20px;
            text-align: center;
            background-color: var(--sc);
        }
        
        .feat h2
        {
            font-size: 2.5rem;
            margin-bottom: 40px;
            color: var(--pc);
            position:relative;
        }
        
         .feat h2::after
        {
            content: '';
            width: 90px;
            height: 4px;
            background-color: #ff9f43;
            display: block;
            margin: 10px auto 0;
        }
        
        .feat .cards
        {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            justify-content: center;
            margin-top: 40px;
        }
        
        .feat .card
        {
            
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            width:400px;
            
            transition: transform 0.3s ease;
        }
        
        .feat .card:hover
        {
            transform: translateY(-15px);
            cursor:pointer;
        }
        
        .feat .card img
        {
            width: 100%;
            height: 240px;
            object-fit: cover;
            border-bottom: 5px solid var(--pc);
        }
      .feat .card img:hover
        {
            //transform:scale(0.999);
            
        }
        .feat .card .info
        {
            padding: 20px;
        }
        
        .feat .card .info h3
        {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: var(--pc);
        }
        
        .feat .card .info p
        {
            font-size: 1rem;
            color: #555;
        }
        
        
        @media (max-width: 768px)
        {
            .hero h1
            {
                font-size: 2.5rem;
            }
        
            .hero p
            {
                font-size: 1.1rem;
            }
        
            .about-slider-container
            {
                flex-direction: column;
            }
        
            .about-section, .slider-section
            {
                max-width: 100%;
            }
        
            .img-slide
            {
                height: 300px;
            }
        
            .feat .cards
            {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }
        }
        
        @media (max-width: 480px)
        {
            .hero h1
            {
                font-size: 2rem;
            }
        
            .hero p
            {
                font-size: 1rem;
            }
        
            .hero .btn
            {
                font-size: 1rem;
                padding: 8px 20px;
            }
        
            .about-section h2
            {
                font-size: 2rem;
            }
        
            .feat h2
            {
                font-size: 2rem;
            }
        }
        
        
        
        
        .contact-container
        {
            padding: 60px 30px;
            background-color: var(--bg);
            text-align: center;
            width: 90%;
            margin: auto;
            margin-bottom: 40px;
        }
        
        .contact-title
        {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
            position: relative;
            display: inline-block;
            color:var(--pc);
        }
        
        .contact-title::after
        {
            content: '';
            width: 90px;
            height: 4px;
            background-color: #ff9f43;
            display: block;
            margin: 10px auto 0;
        }
        
        .contact-content
        {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 40px;
        }
        
        .contact-info
        {
            flex: 1;
            max-width: 40%;
            text-align: left;
            font-size: 1rem;
            line-height: 1.5;
            margin-right: 3%;
            margin-top:18.5px;
        }
        
        .contact-info i
        {
            margin-right: 10px;
            color: #ff9f43;
        }
        
        .contact-form
        {
            flex: 1;
            max-width: 40%;
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-left: 10%;
        }
        
        .contact-input
        {
            width: 90%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            resize: none;
        }
        
        .contact-input:focus
        {
            border-color: #ff9f43;
            outline: none;
        }
        
        .contact-btn
        {
            background-color: #4F7E76;
            color: white;
            font-size: 1rem;
            padding: 10px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 40%;
        }
        
        .contact-btn:hover
        {
            background-color: #3d6459;
        }
        
        @media (max-width: 768px)
        {
            .contact-content
            {
                flex-direction: column;
            }
        
            .contact-info, .contact-form
            {
                max-width: 100%;
            }
        }
        
        
        
        
        
        @keyframes appear {
            from {
                opacity:0;
                scale:0.5;
            } to
            {
                opacity:1;
                scale:1;
                }  
        }
        
        
        @keyframes appear2 {
            from {
                opacity:0;
                transform:translateX(-100px);
            } to
            {
                opacity:1;
                transform:translateX(0px);
                }  
        }
        
        
        @keyframes appear1 {
            from {
                opacity:0;
                clip-path:inset(100% 100% 0 0);
            } to
            {
                opacity:1;
                clip-path:inset(0 0 0 0);
                }  
        }
        
        .about-slider-container, .about-section, .feat, .contact-container, .hero
        {
            animation:appear linear;
            animation-timeline:view();
            animation-range:entry 0% cover 33%;
            
            
            }
            
            
          .feat .cards .card
          {
            animation:appear linear;
            animation-timeline:view();
            animation-range:entry 0% cover 33%;
              }
            
            
            
        .search-container {
            position: relative;
            width: 60%;
            max-width: 500px;
            margin-top: 20px;
        }

        .search-input {
            width: 100%;
            padding: 12px 20px;
            font-size: 1rem;
            border: none;
            border-radius: 30px;
            outline: none;
            transition: box-shadow 0.3s ease;
        }

        .search-input:focus {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .suggestions {
            position: absolute;
            width:97%;
            top: 100%;
            left: 0;
            right: 0;
            backdrop-filter:blur(10px);
            border-radius: 30px;
            margin-top: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            max-height: 200px;
            overflow-y: auto;
            color:#fff;
            font-weight:500;
        }

        .suggestions p {
            padding: 10px;
            margin: 0;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .suggestions p:hover {
            background: var(--sc);
            color:#000;
        }

            
      .explore-btn, .order-btn {
            background: #4F7E76;
            padding: 12px 22px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            color: white;
            border: none;
            cursor: pointer;
            transition: background 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 10px rgba(79, 126, 118, 0.3);
        }

        .explore-btn:hover, .order-btn:hover {
            background: #3d635d;
            box-shadow: 0 6px 15px rgba(79, 126, 118, 0.4);
        }
      
    
    
    .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px; 
        }

        .card {
            width: 30%; 
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            text-align: center;
            padding: 15px;
        }

        .card img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .card .info {
            padding: 10px;
        }

        @media (max-width: 768px) {
            .card {
                width: 45%; 
            }
        }

        @media (max-width: 480px) {
            .card {
                width: 100%; 
            }
        }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
          .search-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px; 
    
        }

        .search-input {
            width: 950px;
            padding: 10px;
            border-radius: 25px;
            border: 2px solid #ccc;
            font-size: 16px;
        }

        .search-btn {
            background-color: white;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
        }

        .search-btn:hover {
            //background-color: #e65c00;
        }
      
    </style>



</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">


    <!-- Hero Section -->
    <%--    <div class="hero">
        <h1>
            Welcome to Cloud Kitchen</h1>
        <p>
            Delicious food delivered right to your door, with love and freshness!</p>
        <button class="btn">
            Order Now</button>
    </div>--%>




    <div class="hero">
        <h1>
            Welcome to Cloud Kitchen
            <% 
                If Session("c_name") IsNot Nothing Then
                    Response.Write(Session("c_name"))
                End If
            %></h1>
        <p>
            Delicious food delivered right to your door, with love and freshness!</p>
        <div class="search-container">
            <input type="text" id="searchBar" class="search-input" placeholder="Search for dishes..." />
            <asp:Button ID="btnSearch" runat="server" CssClass="search-btn" Text=" 🔍 " OnClientClick="saveSearchValue(); return true;"
                OnClick="btnSearch_Click" />
            <asp:HiddenField ID="hiddenSearch" runat="server" />
            <br />
            <div id="suggestions" class="suggestions">
            </div>
        </div>
    </div>
    <%--

        <asp:Repeater ID="rptFeatured" runat="server">
            <ItemTemplate>


                <div class="feat">
                    <h2>
                        Featured Dishes</h2>
                    <div class="cards">
                        <div class="card">
                            <img src='<%# Eval("m_image_url") %>' alt="Dish 1"><div class="info">
                                <h3><%# Eval("m_name") %></h3>
                                <p><%# Eval("m_description") %></p>
                            </div>
                        </div>
                    </div>
                </div>

                </ItemTemplate>
        </asp:Repeater>--%>








    <asp:Repeater ID="rptFeatured" runat="server">
        <HeaderTemplate>
            <div class="feat">
                <h2>
                    Featured Dishes</h2>
                <div class="cards-container">
        </HeaderTemplate>
        <ItemTemplate>
            <div class="card">
                <a href="Menu.aspx">
                    <img src='<%# Eval("m_image_url") %>' alt="Dish Image"></a>
                <div class="info">
                    <h3>
                        <%# Eval("m_name") %></h3>
                    <p>
                        <%# Eval("m_description") %></p>
                </div>
            </div>
        </ItemTemplate>
        <FooterTemplate>
            </div> </div>
        </FooterTemplate>
    </asp:Repeater>




    <%--

        <div class="feat">
        <h2>
            Featured Dishes</h2>
        <div class="cards">
            <div class="card">
                <img src="../Images/gallery-2.jpg" alt="Dish 1"><div class="info">
                    <h3>
                        Dish 1</h3>
                    <p>
                        Delicious and fresh!</p>
                </div>
            </div>
            <div class="card">
                <img src="../Images/gallery-3.jpg" alt="Dish 2"><div class="info">
                    <h3>
                        Dish 2</h3>
                    <p>
                        Rich and flavorful!</p>






                </div>
            </div>
            <div class="card">
                <img src="../Images/gallery-4.jpg" alt="Dish 2"><div class="info">
                    <h3>
                        Dish 2</h3>
                    <p>
                        Rich and flavorful!</p>
                </div>
            </div>

        </div>
    </div>

    --%>
    <asp:ScriptManager ID="ScriptManager1" runat="server">
    </asp:ScriptManager>
    <div class="about-slider-container">


        <div class="slider-section">
            <div class="img-slide" id="slider">
                <img src="../Images/hero-bg.jpg" class="slide-img active" />
                <img src="../Images/hero-bg1.jpg" class="slide-img" />
                <img src="../Images/img3.jpg" class="slide-img" />
                <img src="../Images/img5.jpg" class="slide-img" />
                <img src="../Images/s1.jpeg" class="slide-img" />
                <img src="../Images/s2.jpeg" class="slide-img" />
                <img src="../Images/gallery-2.jpg" class="slide-img" />
                <img src="../Images/gallery-3.jpg" class="slide-img" />
                <img src="../Images/gallery-4.jpg" class="slide-img" />
            </div>
        </div>




        <div class="about-section">
            <h2 align="center">
                About Us</h2>
            <!--<p>At Cloud Kitchen, we pride ourselves on serving fresh and delicious meals straight to your home.</p> -->
            <p align="center">
                At Your, we are passionate about crafting delightful meals that bring joy to your
                taste buds and warmth to your heart. Our journey began with a simple yet powerful
                vision: to serve fresh, delicious, and high-quality food conveniently delivered
                to your doorstep.</p>
        </div>


    </div>

    <style>
        .ddd{
      display: flex;
            justify-content: center;
            align-items: center;
            min-height: 30vh;
            margin: 0;
           // background-color: #f0f4f8;
            font-family: 'Roboto', sans-serif;
        }

        .message-container {
            width: 800px;
            height: 150px;
            //background: linear-gradient(135deg, #ffffff, #e6e9f0);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            padding: 25px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .message-container:hover {
            transform: scale(1.02);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }

        .message-item {
            display: none;
            text-align: center;
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 90%;
        }

        .message-item.active {
            display: block;
            opacity: 1;
        }

        .message-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin: 0 auto 15px;
            background-color: #4a90e2;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(74,144,226,0.3);
        }

        .message-name {
            font-size: 18px;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .message-text {
            font-size: 16px;
            color: #34495e;
            line-height: 1.6;
        }

        .message-meta {
            position: absolute;
            bottom: 15px;
            left: 0;
            width: 100%;
            text-align: center;
            font-size: 12px;
            color: #7f8c8d;
        }

        .progress-bar {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 4px;
            background-color: #4a90e2;
            width: 0;
            transition: width 3s linear;
        }
    </style>
    
   
 
 <div class="feat">
  <h2 class="contact-title">What our customers say</h2>
  <div class="ddd">
  <div class="message-container">
        <asp:Repeater ID="rptReadMessages" runat="server">
            <ItemTemplate>
                <div class="message-item">
                    <div class="message-avatar">
                        <%# Eval("name").ToString().Substring(0,1).ToUpper() %>
                    </div>
                    <div class="message-name"><%# Eval("name") %></div>
                    <div class="message-text"><%# Eval("message") %></div>
                </div>
            </ItemTemplate>
        </asp:Repeater>

        <div class="message-meta">Recent Community Messages</div>
        <div class="progress-bar"></div>
    </div>
      </div>
        </div>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const messageContainer = document.querySelector('.message-container');
            const messages = document.querySelectorAll(".message-item");
            const progressBar = document.querySelector(".progress-bar");
            let currentIndex = 0;

            function resetProgressBar() {
                progressBar.style.width = '0';
            }

            function showNextMessage() {
                messages.forEach(msg => msg.classList.remove('active'));
                
                messages[currentIndex].classList.add('active');
                
                progressBar.style.width = '100%';
                
                currentIndex = (currentIndex + 1) % messages.length;
            }

            if (messages.length > 0) {
                showNextMessage();

                const messageInterval = setInterval(() => {
                    showNextMessage();
                }, 4500);

                messageContainer.addEventListener('mouseenter', () => {
                    clearInterval(messageInterval);
                    resetProgressBar();
                });

                messageContainer.addEventListener('mouseleave', () => {
                    showNextMessage();
                    messageInterval = setInterval(() => {
                        showNextMessage();
                    }, 4500);
                });
            }
        });
    </script>

    <asp:UpdatePanel ID="UpdatePanel2" runat="server">
        <ContentTemplate>


            <div class="contact-container">
                <h2 class="contact-title">
                    Feedback</h2>
                <div class="contact-content">
                    <div class="contact-form">
                        <br />
                        <asp:TextBox ID="txtName" runat="server" placeholder="Name" CssClass="contact-input"
                            ReadOnly></asp:TextBox>
                        <asp:TextBox ID="txtEmail" runat="server" placeholder="Email" CssClass="contact-input"
                            ReadOnly></asp:TextBox>
                        <asp:TextBox ID="txtMessage" runat="server" placeholder="Message" TextMode="MultiLine"
                            Rows="5" CssClass="contact-input"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvMessage" runat="server" ControlToValidate="txtMessage"
                            ErrorMessage="Please Enter The Message" CssClass="error-message" Display="Dynamic"
                            ForeColor="Red" />
                        <asp:Label ID="Label1" runat="server" Font-Bold="True" Font-Italic="False" ForeColor="#4F7E76"></asp:Label>
                        <asp:Button ID="btnSubmit" runat="server" Text="Submit" CssClass="contact-btn" />
                    </div>



                    <div class="contact-info">
                        <p>
                            <i>
                                <img src="../icons/location1.png" style="width: 20px; height: 20px;" /></i>101/BL
                            Semcom College Opp. Shastri Maidan</p>
                        <p>
                            <i>
                                <img src="../icons/mail.png" style="width: 20px; height: 20px;" /></i>info@cloudkitchen.com</p>
                        <p>
                            <i>
                                <img src="../icons/call1.png" style="width: 20px; height: 20px;" /></i></i>8160698196</p>
                        <p>
                            <i>
                                <img src="../icons/open.png" style="width: 20px; height: 20px;" /></i>Monday
                            - Friday: 9:00 AM - 5:00 PM</p>
                        <p>
                            <i>
                                <img src="../icons/open.png" style="width: 20px; height: 20px;" /></i>Saturday:
                            10:00 AM - 3:00 PM (First And Third)</p>
                        <p>
                            <i>
                                <img src="../icons/close1.png" style="width: 20px; height: 20px;" /></i>Sunday:
                            Closed</p>
                        <p>
                            <i>
                                <img src="../icons/url.png" style="width: 20px; height: 20px;" /></i>www.mykitchen.com</p>
                    </div>


                </div>



            </div>
        </ContentTemplate>
    </asp:UpdatePanel>



















    <script type="text/javascript">


        document.addEventListener('DOMContentLoaded', function () {
            const slides = document.querySelectorAll('.slide-img');
            let currentSlide = 0;

            setInterval(() => {
                slides[currentSlide].classList.remove('active');
                currentSlide = (currentSlide + 1) % slides.length;+

                slides[currentSlide].classList.add('active');
            }, 3000);
        });
    
    
    
    </script>










<script type="text/javascript">
    
                document.addEventListener('DOMContentLoaded', function () {
                    const searchBar = document.getElementById('searchBar');
                    const suggestions = document.getElementById('suggestions');
                    let dishes = []; 


                    fetch('Home.aspx/GetMenuItems', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({})
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.d) {
                            dishes = JSON.parse(data.d); 
                        } else {
                            dishes = data; 
                        }
                    })
                    .catch(error => console.error('Error fetching menu items:', error));


                    searchBar.addEventListener('input', function () {
                        const input = searchBar.value.toLowerCase();
                        suggestions.innerHTML = ''; 

                        if (input.length > 0) {
                            const filteredDishes = dishes.filter(dish => dish.toLowerCase().includes(input));
                            filteredDishes.forEach(dish => {
                                const suggestionItem = document.createElement('p');
                                suggestionItem.textContent = dish;
                                suggestionItem.classList.add('suggestion-item'); 

                                suggestionItem.addEventListener('click', function () {
                                    searchBar.value = dish;
                                    suggestions.innerHTML = ''; 
                                });

                                suggestions.appendChild(suggestionItem);
                            });

                            if (filteredDishes.length === 0) {
                                suggestions.innerHTML = '<p class="no-results">No matching dishes found.</p>';
                            }
                        }
                    });

                    document.addEventListener('click', function (e) {
                        if (!e.target.closest('.search-container')) {
                            suggestions.innerHTML = '';
                        }
                    });
                });






                function searchBar_onclick() {

                }

                function saveSearchValue() {
                    var searchValue = document.getElementById("searchBar").value;
                    document.getElementById("<%= hiddenSearch.ClientID %>").value = searchValue;
                }


    </script>

    <script>
let isScrolling = false;

document.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown' && !isScrolling) {
        isScrolling = true;
        smoothScroll(50, 300); 
    }
});

document.addEventListener('keyup', function (e) {
    if (e.key === 'ArrowDown') {
        isScrolling = false;
    }
});

function smoothScroll(scrollDistance, duration) {
    let startTime = null;
    let currentPosition = window.scrollY;

    function animateScroll(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = timestamp - startTime;
        const percentage = Math.min(progress / duration, 2);
        window.scrollTo(0, currentPosition + scrollDistance * percentage);

        if (percentage < 1 && isScrolling) {
            requestAnimationFrame(animateScroll);
        } else if (isScrolling) {
            startTime = null;
            currentPosition = window.scrollY;
            requestAnimationFrame(animateScroll); // Keep scrolling if the key is still pressed
        }
    }

    requestAnimationFrame(animateScroll);
}
</script>

</asp:Content>
