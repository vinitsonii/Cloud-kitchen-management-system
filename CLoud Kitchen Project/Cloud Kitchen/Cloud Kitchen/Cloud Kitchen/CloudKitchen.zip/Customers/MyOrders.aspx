﻿<%@ Page Title="My Orders" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master" CodeBehind="MyOrders.aspx.vb" Inherits="Cloud_Kitchen.MyOrders" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style>
        
.hero-section {
    background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('../Images/img9.jpg') center/cover no-repeat;
    height: 280px;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 32px;
    font-weight: 700;
    text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.5);
    position: relative;
    overflow: hidden;
}

.hero-section::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 20px;
    background: linear-gradient(to top, rgba(255, 255, 255, 1), rgba(255, 255, 255, 0));
}

.hero-section h2 {
    font-family: 'Poppins', sans-serif;
    letter-spacing: 1px;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
}

.thank-you-icon {
    width: 60px;
    height: 60px;
    filter: drop-shadow(0 0 8px rgba(255, 255, 255, 0.6));
}

.orders-container {
    max-width: 1300px;
    margin: -40px auto 50px;
    font-family: 'Poppins', sans-serif;
    position: relative;
    z-index: 10;
    padding: 0 20px;
}

.filters {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    justify-content: center;
    background: #fff;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.filters::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(to right, #007BFF, #00C6FF);
}

.filter-item {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 500;
    color: #444;
}

.styled-dropdown, .styled-input {
    padding: 12px 18px;
    font-size: 14px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    background: #f8f9fa;
    transition: all 0.3s ease;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05);
    color: #333;
    font-family: 'Poppins', sans-serif;
    width: auto;
    min-width: 180px;
}

.styled-dropdown:hover, .styled-input:hover {
    border-color: #007BFF;
    background: #fff;
}

.styled-dropdown:focus, .styled-input:focus {
    outline: none;
    border-color: #007BFF;
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.15);
    background: #fff;
}

.orders-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
    gap: 25px;
    padding: 10px 0;
}

.order-card {
    background: #fff;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
    transition: transform 0.4s ease, box-shadow 0.4s ease;
    position: relative;
    border-left: none;
    overflow: hidden;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.order-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 6px;
    height: 100%;
    //background: linear-gradient(to bottom, #007BFF, #00C6FF);
    border-radius: 4px 0 0 4px;
}

.order-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.order-header {
    font-size: 18px;
    font-weight: 700;
    color: #333;
    margin-bottom: 18px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 12px;
    border-bottom: 1px solid #f0f0f0;
}

.order-info {
    font-size: 14px;
    color: #555;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    transition: all 0.3s ease;
}

.order-info:hover {
    transform: translateX(5px);
    color: #007BFF;
}

.icon {
    display: inline-flex;
    margin-right: 12px;
    width: 28px;
    height: 28px;
    justify-content: center;
    align-items: center;
    background: rgba(0, 123, 255, 0.1);
    border-radius: 50%;
    padding: 5px;
}

.icon img 
{
    width:20px;
   // filter: brightness(0) saturate(100%) invert(36%) sepia(98%) saturate(1900%) hue-rotate(200deg) brightness(100%) contrast(101%);
}

.status {
    font-weight: 600;
    padding: 8px 16px;
    border-radius: 30px;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

.status-pending {
    background: linear-gradient(45deg, #ff9800, #ff5722);
    color: #fff;
}

.status-completed {
    background: linear-gradient(45deg, #4CAF50, #009688);
    color: #fff;
}

.status-cancelled {
    background: linear-gradient(45deg, #e74c3c, #c0392b);
    color: #fff;
}

.order-items {
    margin-top: 18px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 12px;
    box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
    border: 1px solid #eee;
}

.order-items strong {
    display: block;
    margin-bottom: 8px;
    color: #333;
    font-size: 15px;
}

.item-row {
    display: flex;
    justify-content: space-between;
    padding: 10px 8px;
    border-bottom: 1px solid #e6e6e6;
    font-size: 14px;
    transition: background 0.2s ease;
}

.item-row:hover {
    background: rgba(0, 123, 255, 0.05);
}

.item-row:last-child {
    border-bottom: none;
}

.btn-filter {
    padding: 13px 20px;
    font-size: 15px;
    font-weight: 600;
    color: #fff;
    background: linear-gradient(45deg, #007BFF, #00C6FF);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
    letter-spacing: 0.5px;
    text-transform: uppercase;
    min-width: 150px;
}

.btn-filter:hover {
    background: linear-gradient(45deg, #0056b3, #007BFF);
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0, 123, 255, 0.4);
}

.btn-filter:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
}

.btn-reorder {
    display: block;
    margin: 20px auto 0;
    padding: 12px 20px;
    font-size: 14px;
    font-weight: 600;
    color: #fff;
    background: linear-gradient(45deg, #007BFF, #00C6FF);
    border: none;
    border-radius: 8px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
    width: 40%;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    position: relative;
    overflow: hidden;
}

.btn-reorder::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.7s ease;
}

.btn-reorder:hover {
    background: linear-gradient(45deg, #0056b3, #007BFF);
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0, 123, 255, 0.3);
}

.btn-reorder:hover::before {
    left: 100%;
}

.btn-reorder:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(0, 123, 255, 0.2);
}

@media (max-width: 768px) {
    .hero-section {
        height: 200px;
        font-size: 26px;
    }
    
    .orders-grid {
        grid-template-columns: 1fr;
    }
    
    .order-card {
        padding: 20px;
    }
    
    .btn-reorder {
        width: 100%;
    }
    
    .filters {
        flex-direction: column;
        padding: 20px;
    }
    
    .filter-item {
        width: 100%;
    }
    
    .styled-dropdown, .styled-input {
        width: 100%;
    }
}

/* Animation effects */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.orders-grid > div {
    animation: fadeIn 0.5s ease forwards;
    opacity: 0;
}

.orders-grid > div:nth-child(1) { animation-delay: 0.1s; }
.orders-grid > div:nth-child(2) { animation-delay: 0.2s; }
.orders-grid > div:nth-child(3) { animation-delay: 0.3s; }
.orders-grid > div:nth-child(4) { animation-delay: 0.4s; }
.orders-grid > div:nth-child(5) { animation-delay: 0.5s; }
.orders-grid > div:nth-child(6) { animation-delay: 0.6s; }

/* Enhanced print bill styling */
.bill-container { 
    width: 100%; 
    max-width: 650px; 
    margin: auto; 
    padding: 30px; 
    border: 1px solid #ddd; 
    border-radius: 15px; 
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    background: #fff;
    position: relative;
    overflow: hidden;
}

.bill-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 8px;
    background: linear-gradient(to right, #007BFF, #00C6FF);
}

.bill-header { 
    text-align: center; 
    font-size: 24px; 
    font-weight: bold; 
    margin-bottom: 20px;
    color: #333;
    padding-bottom: 15px;
    border-bottom: 2px dashed #eee;
    position: relative;
}

.bill-header::after {
    content: 'INVOICE';
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 40px;
    color: rgba(0, 0, 0, 0.03);
    font-weight: 900;
    letter-spacing: 2px;
}

.bill-info { 
    margin-bottom: 25px;
    line-height: 1.8;
    color: #555;
}

.bill-table { 
    width: 100%; 
    border-collapse: collapse; 
    margin: 20px 0; 
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    overflow: hidden;
    border-radius: 10px;
}

.bill-table th { 
    background: #f5f5f5; 
    color: #333;
    padding: 12px; 
    text-align: left;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 14px;
}

.bill-table td { 
    padding: 12px; 
    text-align: left;
    border-bottom: 1px solid #eee;
}

.bill-table tr:last-child td {
    border-bottom: none;
}

.bill-footer { 
    text-align: right; 
    font-weight: bold; 
    margin-top: 20px;
    padding-top: 15px;
    border-top: 2px dashed #eee;
    color: #007BFF;
    font-size: 18px;
}

.btn-close { 
    display: block; 
    margin: 30px auto; 
    padding: 12px 25px; 
    background: linear-gradient(45deg, #007BFF, #00C6FF); 
    color: white; 
    border: none; 
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    letter-spacing: 1px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
}

.btn-close:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 15px rgba(0, 123, 255, 0.4);
}
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

    <div class="hero-section">
         <img src="../icons/manageitem.png" alt="" class="thank-you-icon" /> &nbsp; &nbsp; <h2> My Orders</h2>
    </div>


    <div class="orders-container">
        

        <!-- Filters -->
<div class="filters">

    <div class="filter-item">
        <label for="ddlStatus">
            <span class="icon"><img src="../icons/total.png" alt="Status" width="24"></span>
            Status:
        </label>
        <asp:DropDownList ID="ddlStatus" runat="server" AutoPostBack="true" CssClass="styled-dropdown" width="50%" OnSelectedIndexChanged="ddlStatus_SelectedIndexChanged">
            <asp:ListItem Text="All" Value=""></asp:ListItem>
            <asp:ListItem Text="Pending" Value="Pending"></asp:ListItem>
            <asp:ListItem Text="Completed" Value="Completed"></asp:ListItem>
            <asp:ListItem Text="Cancelled" Value="Cancelled"></asp:ListItem>
        </asp:DropDownList>
    </div>

    <div class="filter-item">
        <label for="txtStartDate">
            <span class="icon"><img src="../icons/cal1.png" alt="" width="16"></span>Start Date:
        </label>
        <asp:TextBox ID="txtStartDate" runat="server" Type="date" CssClass="styled-input"></asp:TextBox>
    </div>

    <div class="filter-item">
        <label for="txtEndDate">
            <span class="icon"><img src="../icons/cal1.png" alt="" width="16"></span>End Date:
        </label>
        <asp:TextBox ID="txtEndDate" runat="server" Type="date" CssClass="styled-input"></asp:TextBox>
    </div>

    <div class="filter-item">
        <asp:Button ID="btnFilter" runat="server" Text="Apply Filters" OnClick="btnFilter_Click" CssClass="btn-filter"/>
    </div>
</div>


        <!-- Orders Grid -->
        <div class="orders-grid">
            <asp:Repeater ID="rptOrders" runat="server">
                <ItemTemplate>
                    <div class="order-card">
                        <div class="order-header">
                            <span class="icon"><img src="../icons/order.png" alt="Order" width="20"></span>
                            Order ID: <%# Eval("order_id") %> | <span style="color: gray;"> <%# Eval("order_date", "{0:dd-MMM-yyyy HH:mm}") %> </span>
                        </div>
                        <div class="order-info">
                            <span class="icon"><img src="../icons/tr.png" alt="Transaction" width="18"></span>
                            <strong>Transaction Number:</strong> <%# Eval("transaction_number") %>
                        </div>
                        <div class="order-info">
                            <span class="icon"><img src="../icons/rupee.png" alt="Amount" width="18"></span>
                            <strong>Total Amount:</strong> ₹<%# Eval("total_amount") %>
                        </div>
                        <div class="order-info">
                            <span class="icon"><img src="../icons/payment.png" alt="Payment" width="18"></span>
                            <strong>Payment Type:</strong> <%# Eval("payment_type") %>
                        </div>
                        <div class="order-info">
                            <span class="icon"><img src="../icons/location1.png" alt="Address" width="18"></span>
                            <strong>Delivery Address:</strong> <%# Eval("delivery_address") %>, <%# Eval("pincode") %>
                        </div>
                        <div class="order-info">
                            <span class="icon"><img src="../icons/status.png" alt="Status" width="18"></span>
                            <strong>Status: &nbsp;&nbsp;</strong> 
                            <span class="status <%# GetStatusClass(Eval("order_status").ToString()) %>">
                                <%# Eval("order_status") %>
                            </span>
                        </div>

                        <div class="order-items">
                            <strong>Items:</strong>
                            <asp:Repeater ID="rptOrderItems" runat="server" DataSource='<%# Eval("OrderItems") %>'>
                                <ItemTemplate>
                                    <div class="item-row">
                                        <span><%# Eval("item_name") %> (x<%# Eval("quantity") %>)</span>
                                        <span>₹<%# Eval("price") %></span>
                                    </div>
                                </ItemTemplate>
                            </asp:Repeater>
                        </div>

                        <asp:Button ID="btnPrintBill" runat="server" CssClass="btn-reorder" Text="Print Bill" 
    Visible='<%# IIf(Convert.ToString(Eval("order_status")) = "Completed", True, False) %>' 
    CommandArgument='<%# Eval("order_id") %>' OnClick="btnPrintBill_Click" />


                        <asp:Button ID="btnReorder" runat="server" CssClass="btn-reorder" Text="Reorder" CommandArgument='<%# Eval("order_id") %>' OnClick="btnReorder_Click" />
                    </div>
                </ItemTemplate>
            </asp:Repeater>
        </div>
    </div>


    <script>
//    function printBill(orderId) {
//        var orderCard = document.getElementById("order_" + orderId);
//        if (!orderCard) {
//            alert("Order details not found!");
//            return;
//        }

//        var printWindow = window.open('', '', 'width=800,height=600');
//        printWindow.document.write('<html><head><title>Print Bill</title>');
//        printWindow.document.write('<style>');
//        printWindow.document.write(`
//            body { font-family: Arial, sans-serif; padding: 20px; }
//            .bill-container { width: 100%; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
//            .bill-header { text-align: center; font-size: 20px; font-weight: bold; margin-bottom: 10px; }
//            .bill-info { margin-bottom: 15px; }
//            .bill-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
//            .bill-table th, .bill-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
//            .bill-footer { text-align: right; font-weight: bold; margin-top: 15px; }
//            .btn-close { display: block; margin: 20px auto; padding: 8px 15px; background: #007BFF; color: white; border: none; cursor: pointer; }
//        `);
//        printWindow.document.write('</style></head><body>');
//        
//        // Extract Order Details
//        printWindow.document.write('<div class="bill-container">');
//        printWindow.document.write('<div class="bill-header">Cloud Kitchen - Invoice</div>');

//        printWindow.document.write('<div class="bill-info">');
//        printWindow.document.write('<strong>Order ID:</strong> ' + orderId + '<br>');
//        printWindow.document.write(orderCard.querySelector('.order-info:nth-child(1)').innerHTML + '<br>');
//        printWindow.document.write(orderCard.querySelector('.order-info:nth-child(2)').innerHTML + '<br>');
//        printWindow.document.write(orderCard.querySelector('.order-info:nth-child(3)').innerHTML + '<br>');
//        printWindow.document.write('</div>');

//        // Extract Items
//        printWindow.document.write('<table class="bill-table"><tr><th>Item</th><th>Qty</th><th>Price</th></tr>');
//        var items = orderCard.querySelectorAll('.item-row');
//        items.forEach(function (item) {
//            printWindow.document.write('<tr>' + item.innerHTML + '</tr>');
//        });
//        printWindow.document.write('</table>');

//        // Total Price
//        printWindow.document.write('<div class="bill-footer">Total Amount: ' + orderCard.querySelector('.order-info:nth-child(4)').innerHTML + '</div>');
//        
//        printWindow.document.write('</div>');
//        printWindow.document.write('<button class="btn-close" onclick="window.print();">Print</button>');
//        printWindow.document.write('</body></html>');

//        printWindow.document.close();
        //    }



function printBill(orderId) {
    var orderCard = document.getElementById("order_" + orderId);
    if (!orderCard) {
        alert("Order details not found!");
        return;
    }
    
    // Get current date for invoice
    const today = new Date();
    const formattedDate = today.toLocaleDateString('en-GB', { 
        day: '2-digit', 
        month: 'short', 
        year: 'numeric' 
    });
    
    // Extract order data
    const transactionInfo = orderCard.querySelector('.order-info:nth-child(1)').innerHTML;
    const amountInfo = orderCard.querySelector('.order-info:nth-child(2)').innerHTML;
    const paymentInfo = orderCard.querySelector('.order-info:nth-child(3)').innerHTML;
    const deliveryInfo = orderCard.querySelector('.order-info:nth-child(4)').innerHTML;
    
    // Get order date if available
    const orderDateText = orderCard.querySelector('.order-header span[style="color: gray;"]')?.textContent || formattedDate;
    
    var printWindow = window.open('', '', 'width=800,height=800');
    printWindow.document.write('<html><head><title>Cloud Kitchen - Invoice</title>');
    printWindow.document.write('<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">');
    printWindow.document.write('<style>');
    printWindow.document.write(`
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', Arial, sans-serif;
        }
        
        body { 
            background-color: #f5f7fa;
            padding: 40px;
            color: #333;
        }
        
        .invoice-container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        
        .invoice-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(to right, #007BFF, #00C6FF);
            border-radius: 16px 16px 0 0;
        }
        
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
            border-bottom: 2px dashed #eee;
            margin-bottom: 30px;
        }
        
        .company-details {
            display: flex;
            flex-direction: column;
        }
        
        .company-name {
            font-size: 28px;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .company-tagline {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .invoice-title {
            text-align: right;
        }
        
        .invoice-title h2 {
            font-size: 40px;
            color: #007BFF;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 5px;
            font-weight: 700;
        }
        
        .invoice-title p {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .invoice-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        
        .invoice-details-left, .invoice-details-right {
            flex: 1;
        }
        
        .invoice-details-right {
            text-align: right;
        }
        
        .detail-title {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-weight: 600;
            color: #2c3e50;
            font-size: 16px;
            margin-bottom: 15px;
        }
        
        .customer-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .customer-title {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .customer-address {
            color: #7f8c8d;
            font-size: 14px;
            line-height: 1.5;
        }
        
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .invoice-table thead {
            background: linear-gradient(to right, #f5f7fa, #f1f5f9);
            color: #2c3e50;
        }
        
        .invoice-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
        }
        
        .invoice-table td {
            padding: 15px;
            border-bottom: 1px solid #ecf0f1;
            color: #2c3e50;
        }
        
        .invoice-table tbody tr:last-child td {
            border-bottom: none;
        }
        
        .invoice-table .item-name {
            width: 50%;
        }
        
        .invoice-table .item-quantity {
            width: 15%;
            text-align: center;
        }
        
        .invoice-table .item-price {
            width: 35%;
            text-align: right;
            font-weight: 600;
        }
        
        .total-section {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px dashed #eee;
        }
        
        .total-row {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .total-label {
            width: 150px;
            text-align: right;
            margin-right: 20px;
            color: #7f8c8d;
        }
        
        .total-value {
            width: 150px;
            text-align: right;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .grand-total {
            font-size: 20px;
            color: #007BFF;
            font-weight: 700;
        }
        
        .footer-note {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ecf0f1;
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .footer-contact {
            margin-top: 10px;
            text-align: center;
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .print-button {
            display: block;
            margin: 30px auto;
            padding: 12px 30px;
            background: linear-gradient(to right, #007BFF, #00C6FF);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.3);
        }
        
        .print-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 123, 255, 0.4);
        }
        
        @media print {
            body {
                background-color: white;
                padding: 0;
            }
            
            .invoice-container {
                box-shadow: none;
                max-width: 100%;
                padding: 20px;
            }
            
            .print-button {
                display: none;
            }
        }
        
        .payment-badge {
            display: inline-block;
            padding: 5px 10px;
            background: rgba(0, 123, 255, 0.1);
            color: #007BFF;
            border-radius: 5px;
            font-weight: 500;
            font-size: 14px;
        }
        
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-35deg);
            font-size: 120px;
            color: rgba(0, 0, 0, 0.03);
            font-weight: 700;
            text-transform: uppercase;
            pointer-events: none;
            z-index: 0;
        }
    `);
    printWindow.document.write('</style></head><body>');
    
    // Build premium invoice
    printWindow.document.write(`
        <div class="invoice-container">
            <div class="watermark">Paid</div>
            
            <div class="invoice-header">
                <div class="company-details">
                    <div class="company-name">Cloud Kitchen</div>
                    <div class="company-tagline">Delicious food delivered to your doorstep</div>
                </div>
                <div class="invoice-title">
                    <h2>Invoice</h2>
                    <p>Receipt for your order</p>
                </div>
            </div>
            
            <div class="invoice-details">
                <div class="invoice-details-left">
                    <div class="detail-title">INVOICE NUMBER</div>
                    <div class="detail-value">INV-${orderId}</div>
                    
                    <div class="detail-title">ORDER DATE</div>
                    <div class="detail-value">${orderDateText}</div>
                </div>
                <div class="invoice-details-right">
                    <div class="detail-title">TRANSACTION ID</div>
                    <div class="detail-value">${extractText(transactionInfo)}</div>
                    
                    <div class="detail-title">PAYMENT METHOD</div>
                    <div class="detail-value"><span class="payment-badge">${extractText(paymentInfo)}</span></div>
                </div>
            </div>
            
            <div class="customer-info">
                <div class="customer-title">DELIVERED TO</div>
                <div class="customer-address">
                    ${extractText(deliveryInfo)}
                </div>
            </div>
            
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th class="item-name">Item</th>
                        <th class="item-quantity">Qty</th>
                        <th class="item-price">Price</th>
                    </tr>
                </thead>
                <tbody>
    `);
    
    var items = orderCard.querySelectorAll('.item-row');
    let subtotal = 0;
    
    items.forEach(function (item) {
        const itemText = item.textContent.trim();
        const itemParts = itemText.split('₹');
        
        if (itemParts.length > 1) {
            const itemNameWithQty = itemParts[0].trim();
            const price = itemParts[1].trim();
            
            // Extract name and quantity
            const matches = itemNameWithQty.match(/(.*)\s+\(x(\d+)\)/);
            if (matches && matches.length > 2) {
                const itemName = matches[1].trim();
                const quantity = matches[2];
                
                printWindow.document.write(`
                    <tr>
                        <td class="item-name">${itemName}</td>
                        <td class="item-quantity">${quantity}</td>
                        <td class="item-price">₹${price}</td>
                    </tr>
                `);
                
                // Add to subtotal (convert price to number)
                const priceNum = parseFloat(price.replace(/,/g, ''));
                if (!isNaN(priceNum)) {
                    subtotal += priceNum;
                }
            }
        }
    });
    
    const tax = subtotal * 0.05;
    const grandTotal = subtotal + tax;
    
    printWindow.document.write(`
            </tbody>
        </table>
        
        <div class="total-section">
            <div class="total-row">
                <div class="total-label">Subtotal</div>
                <div class="total-value">₹${subtotal.toFixed(2)}</div>
            </div>
            <div class="total-row">
                <div class="total-label">Tax (5% GST)</div>
                <div class="total-value">₹${tax.toFixed(2)}</div>
            </div>
            <div class="total-row">
                <div class="total-label">Delivery Fee</div>
                <div class="total-value">₹0.00</div>
            </div>
            <div class="total-row">
                <div class="total-label grand-total">GRAND TOTAL</div>
                <div class="total-value grand-total">₹${grandTotal.toFixed(2)}</div>
            </div>
        </div>
        
        <div class="footer-note">
            Thank you for your order! We hope you enjoyed your meal.
        </div>
        <div class="footer-contact">
            If you have any questions about this invoice, please contact us at support@cloudkitchen.com
        </div>
    </div>
    
    <button class="print-button" onclick="window.print();">Print Invoice</button>
    `);
    
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    
    // Helper function to extract text from HTML
    function extractText(html) {
        const div = document.createElement('div');
        div.innerHTML = html;
        
        // Find the strong element and remove it
        const strongElement = div.querySelector('strong');
        if (strongElement) {
            strongElement.remove();
        }
        
        // Find and remove any icons
        const iconElement = div.querySelector('.icon');
        if (iconElement) {
            iconElement.remove();
        }
        
        return div.textContent.trim().replace(/:/g, '');
    }
}


</script>

</asp:Content>