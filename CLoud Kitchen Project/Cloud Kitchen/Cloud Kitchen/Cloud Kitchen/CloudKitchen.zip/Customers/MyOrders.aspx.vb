﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO

Partial Class MyOrders
    Inherits System.Web.UI.Page

    Dim connString As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Session("c_id") Is Nothing Then
                Response.Redirect("Login.aspx")
            End If
            LoadOrders()
        End If
    End Sub
    Protected Sub ddlStatus_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        LoadOrders()
    End Sub

    Protected Sub btnFilter_Click(ByVal sender As Object, ByVal e As EventArgs)
        LoadOrders()
    End Sub

    Private Sub LoadOrders()
        Dim statusFilter As String = ddlStatus.SelectedValue
        Dim startDate As String = txtStartDate.Text
        Dim endDate As String = txtEndDate.Text

        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT order_id, order_date, transaction_number, total_amount, payment_type, address AS delivery_address, pincode, order_status FROM Orders WHERE c_id = @CustomerId"

            ' Add Status Filter
            If Not String.IsNullOrEmpty(statusFilter) Then
                query &= " AND order_status = @Status"
            End If

            ' Add Date Range Filter
            If Not String.IsNullOrEmpty(startDate) And Not String.IsNullOrEmpty(endDate) Then
                query &= " AND order_date BETWEEN @StartDate AND @EndDate"
            End If

            query &= " ORDER BY order_date DESC"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@CustomerId", Session("c_id"))

            ' Add status parameter if a filter is selected
            If Not String.IsNullOrEmpty(statusFilter) Then
                cmd.Parameters.AddWithValue("@Status", statusFilter)
            End If

            ' Add date parameters if a range is selected
            If Not String.IsNullOrEmpty(startDate) And Not String.IsNullOrEmpty(endDate) Then
                cmd.Parameters.AddWithValue("@StartDate", Convert.ToDateTime(startDate))
                cmd.Parameters.AddWithValue("@EndDate", Convert.ToDateTime(endDate).AddDays(1)) ' Include full end date
            End If

            Dim dt As New DataTable()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(dt)

            ' Fetch order items for each order
            dt.Columns.Add("OrderItems", GetType(DataTable)) ' Add new column for nested data
            For Each row As DataRow In dt.Rows
                Dim orderId As Integer = Convert.ToInt32(row("order_id"))
                row("OrderItems") = GetOrderItems(orderId)
            Next

            rptOrders.DataSource = dt
            rptOrders.DataBind()
        End Using
    End Sub


    Private Function GetOrderItems(ByVal orderId As Integer) As DataTable
        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT mi.m_name AS item_name, od.quantity, od.price, od.total_price FROM Order_Details od INNER JOIN Menu_Item mi ON od.m_id = mi.m_id WHERE od.order_id = @OrderId"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@OrderId", orderId)

            Dim dt As New DataTable()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(dt)
            Return dt
        End Using
    End Function

    Public Function GetStatusClass(ByVal orderStatus As String) As String
        Select Case orderStatus.ToLower()
            Case "pending"
                Return "status-pending"
            Case "completed"
                Return "status-completed"
            Case "cancelled"
                Return "status-cancelled"
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub btnReorder_Click(ByVal sender As Object, ByVal e As EventArgs)
        If Session("c_id") IsNot Nothing Then
            Dim btn As Button = CType(sender, Button)
            Dim orderId As Integer

            ' Ensure the Order ID is valid
            If Integer.TryParse(btn.CommandArgument.ToString(), orderId) Then
                Dim cart As List(Of Dictionary(Of String, Object))

                ' Initialize the cart if it doesn't exist
                If Session("Cart") Is Nothing Then
                    cart = New List(Of Dictionary(Of String, Object))
                Else
                    cart = CType(Session("Cart"), List(Of Dictionary(Of String, Object)))
                End If

                ' Retrieve all items from the selected order
                Dim orderItems As List(Of Dictionary(Of String, Object)) = GetOrderItemsList(orderId)

                ' Loop through each item and add/update in the session cart
                For Each item In orderItems
                    Dim menuId As Integer = Convert.ToInt32(item("m_id"))

                    ' Check if item already exists in cart
                    Dim existingItem = cart.FirstOrDefault(Function(x) x("m_id") = menuId)

                    If existingItem IsNot Nothing Then
                        existingItem("quantity") += item("quantity")
                        existingItem("total_price") = existingItem("quantity") * existingItem("m_final_price")
                    Else
                        Dim menuItem As Dictionary(Of String, Object) = GetMenuItem(menuId)

                        If menuItem IsNot Nothing AndAlso menuItem.Count > 0 Then
                            menuItem("quantity") = item("quantity")
                            menuItem("total_price") = menuItem("quantity") * menuItem("m_final_price")
                            cart.Add(menuItem)
                        End If
                    End If
                Next

                ' Store updated cart back in session
                Session("Cart") = cart

                ' Redirect to cart page
                Response.Redirect("Cart.aspx")
            End If
        End If
    End Sub

    Private Function GetMenuItem(ByVal menuId As Integer) As Dictionary(Of String, Object)
        Dim menuItem As New Dictionary(Of String, Object)()

        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT m_id, m_name, m_image_url, m_final_price FROM Menu_Item WHERE m_id = @MenuId"
            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@MenuId", menuId)

            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            If reader.Read() Then
                menuItem("m_id") = reader("m_id")
                menuItem("m_name") = reader("m_name")
                menuItem("m_image_url") = reader("m_image_url")
                menuItem("m_final_price") = reader("m_final_price")
            End If
        End Using

        Return menuItem
    End Function

    Private Function GetOrderItemsList(ByVal orderId As Integer) As List(Of Dictionary(Of String, Object))
        Dim orderItems As New List(Of Dictionary(Of String, Object))()

        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT mi.m_id, mi.m_name, mi.m_image_url, mi.m_final_price, od.quantity " &
                                  "FROM Order_Details od " &
                                  "INNER JOIN Menu_Item mi ON od.m_id = mi.m_id " &
                                  "WHERE od.order_id = @OrderId"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@OrderId", orderId)

            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            While reader.Read()
                Dim item As New Dictionary(Of String, Object) From {
                    {"m_id", reader("m_id")},
                    {"m_name", reader("m_name")},
                    {"m_image_url", reader("m_image_url")},
                    {"m_final_price", reader("m_final_price")},
                    {"quantity", reader("quantity")}
                }
                orderItems.Add(item)
            End While
        End Using

        Return orderItems
    End Function
    Protected Sub btnPrintBill_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim btn As Button = CType(sender, Button)
        Dim orderId As String = btn.CommandArgument
        Dim dt As DataTable = GetOrderDetails(orderId)
        Dim customerDetails As DataRow = GetCustomerDetails(orderId)

        If dt.Rows.Count > 0 AndAlso customerDetails IsNot Nothing Then
            Dim htmlContent As String = GenerateInvoiceHTML(dt, customerDetails)

            Response.Clear()
            Response.Write("<html><head>")
            Response.Write("<script>")
            Response.Write("window.onload = function() { window.print(); };")
            Response.Write("</script>")
            Response.Write("</head><body>")
            Response.Write(htmlContent)
            Response.Write("</body></html>")
            Response.End()
        End If
    End Sub



    Private Function GetOrderDetails(ByVal orderId As String) As DataTable
        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT o.order_id, o.total_amount, o.order_date, o.payment_type, o.address, o.pincode, " &
                                  "od.quantity, od.price, od.total_price, mi.m_name " &
                                  "FROM Orders o " &
                                  "INNER JOIN Order_Details od ON o.order_id = od.order_id " &
                                  "INNER JOIN Menu_Item mi ON od.m_id = mi.m_id " &
                                  "WHERE o.order_id = @OrderId"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@OrderId", orderId)

            Dim dt As New DataTable()
            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(dt)
            Return dt
        End Using
    End Function

    Private Function GenerateInvoiceHTML(ByVal dt As DataTable, ByVal customer As DataRow) As String
        Dim html As New StringBuilder()

        ' Invoice Header
        html.Append("<html><head>")
        html.Append("<style>")
        html.Append("body { font-family: Arial, sans-serif; margin: 20px; padding: 10px; }")
        html.Append(".invoice-container { max-width: 700px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; background: #f9f9f9; }")
        html.Append(".invoice-header { text-align: center; padding-bottom: 20px; border-bottom: 2px solid #007bff; }")
        html.Append(".invoice-header h2 { color: #007bff; margin: 0; }")
        html.Append(".invoice-details { margin-top: 20px; }")
        html.Append("table { width: 100%; border-collapse: collapse; margin-top: 20px; }")
        html.Append("th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }")
        html.Append("th { background: #007bff; color: white; }")
        html.Append("td:last-child, th:last-child { text-align: right; }")
        html.Append(".total-section { text-align: right; font-size: 18px; font-weight: bold; margin-top: 20px; }")
        html.Append(".print-button { text-align: center; margin-top: 20px; }")
        html.Append("button { background: #007bff; color: white; border: none; padding: 10px 20px; font-size: 16px; cursor: pointer; border-radius: 5px; }")
        html.Append("button:hover { background: #0056b3; }")
        html.Append("</style>")
        html.Append("<script>")
        html.Append("function printInvoice() { window.print(); }")
        html.Append("</script>")
        html.Append("</head><body>")

        ' Invoice Container
        html.Append("<div class='invoice-container'>")

        ' Header Section
        html.Append("<div class='invoice-header'>")
        html.Append("<h2>INVOICE</h2>")
        html.Append("<p><strong>Cloud Kitchen</strong></p>")
        html.Append("<p>101/BL Semcom College Opp. Shastri Maidan</p>")
        html.Append("<p>Email: info@cloudkitchen.com | Phone: +91 8160698196</p>")
        html.Append("</div>")

        ' Customer Details
        html.Append("<div class='invoice-details'>")
        html.Append("<p><strong>Customer Name: </strong> " & customer("C_Name") & "</p>")
        html.Append("<p><strong>Phone: </strong> " & customer("Phone") & "</p>")
        html.Append("<p><strong>Address: </strong> " & customer("address") & ", " & customer("pincode") & "</p>")
        html.Append("<hr>")
        html.Append("</div>")

        ' Order Items Table
        html.Append("<table>")
        html.Append("<tr><th>Item Name</th><th>Quantity</th><th>Price</th><th>Total</th></tr>")

        Dim grandTotal As Decimal = 0

        For Each row As DataRow In dt.Rows
            Dim totalPrice As Decimal = Convert.ToDecimal(row("total_price"))
            grandTotal += totalPrice

            html.Append("<tr>")
            html.Append("<td>" & row("m_name") & "</td>")
            html.Append("<td>" & row("quantity") & "</td>")
            html.Append("<td>" & Convert.ToDecimal(row("price")).ToString("C2") & "</td>")
            html.Append("<td>" & totalPrice.ToString("C2") & "</td>")
            html.Append("</tr>")
        Next

        html.Append("</table>")

        ' Grand Total
        html.Append("<div class='total-section'>")
        html.Append("Grand Total: " & grandTotal.ToString("C2"))
        html.Append("</div>")

        ' Print Button
        html.Append("<div class='print-button'>")
        html.Append("<button onclick='printInvoice()'>Print Invoice</button>")
        html.Append("</div>")

        html.Append("</div>") ' End Invoice Container

        html.Append("</body></html>")

        Return html.ToString()
    End Function

    Private Function GetCustomerDetails(ByVal orderId As String) As DataRow
        Dim dt As New DataTable()

        Using conn As New SqlConnection(connString)
            Dim query As String = "SELECT c.C_Name, c.Phone, o.address, o.pincode " &
                                  "FROM Orders o INNER JOIN Customers c ON o.c_id = c.C_Id " &
                                  "WHERE o.order_id = @OrderId"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@OrderId", orderId)

            Dim adapter As New SqlDataAdapter(cmd)
            adapter.Fill(dt)
        End Using

        If dt.Rows.Count > 0 Then
            Return dt.Rows(0)
        End If

        Return Nothing
    End Function

End Class
