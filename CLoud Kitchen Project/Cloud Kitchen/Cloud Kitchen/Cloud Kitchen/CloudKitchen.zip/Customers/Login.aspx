﻿<%@ Page Title="Login" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master" CodeBehind="Login.aspx.vb" Inherits="Cloud_Kitchen.WebForm3" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        :root {
            --primary: #4F7E76;
            --primary-dark: #3a5f59;
            --secondary: #f4f4f4;
            --background: #f9fafc;
            --text: #333;
            --accent: #ff6b4a;
            --accent-hover: #e35a3c;
            --form-bg: #ffffff;
            --form-border: #e8e8e8;
            --form-shadow: rgba(0, 0, 0, 0.08);
            --input-border: #dbe0e6;
            --input-focus: rgba(79, 126, 118, 0.25);
        }

        body {
            font-family: 'Poppins', 'Open Sans', sans-serif;
            background: linear-gradient(145deg, #f0f4f8, #ffffff);
            margin: 0;
            color: var(--text);
            line-height: 1.6;
        }

        .login-container {
            display: flex;
            min-height: 100vh;
            max-width: 1600px;
            margin: 0 auto;
            box-shadow: 0 5px 30px rgba(0, 0, 0, 0.1);
        }

        .login-image-section {
            flex: 1.2;
            position: relative;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.65)), 
                        url('../Images/lb5.jpeg') center/cover no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: #fff;
            padding: 2rem;
            overflow: hidden;
        }

        .login-image-section::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: linear-gradient(135deg, rgba(79, 126, 118, 0.3), rgba(0, 0, 0, 0.4));
            z-index: 1;
        }

        .login-image-section .cont {
            position: relative;
            z-index: 2;
            max-width: 500px;
        }

        .login-image-section h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            letter-spacing: 0.5px;
        }

        .login-image-section p {
            font-size: 1.25rem;
            font-weight: 300;
            line-height: 1.6;
            text-shadow: 0 1px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 0;
        }

        .login-form-section {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            background-color: var(--form-bg);
        }

        .form-card {
            width: 100%;
            max-width: 450px;
            background: var(--form-bg);
            padding: 2.5rem;
            border-radius: 16px;
            border: 1px solid var(--form-border);
            box-shadow: 0 15px 35px var(--form-shadow);
            animation: fadeInUp 0.8s ease-out;
        }

        .form-card h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: var(--primary);
            font-size: 2rem;
            font-weight: 600;
        }

        .form-card hr {
            border: none;
            height: 3px;
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            margin: 1.5rem 0;
            border-radius: 2px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            display: block;
            color: #3a4a5b;
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: #fafbfc;
            box-sizing: border-box;
        }

        .form-group input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 4px var(--input-focus);
            background-color: #fff;
        }

        .password-input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            font-size: 1rem;
            background-color: #fafbfc;
            box-sizing: border-box;
        }

        .password-container {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 1.1rem;
            color: #5a6a7a;
            z-index: 10;
            background: none;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.25rem;
        }

        .toggle-password:hover {
            color: var(--primary);
        }

        .login-btn {
            width: 100%;
            padding: 0.9rem;
            font-size: 1.1rem;
            font-weight: 600;
            color: white;
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(79, 126, 118, 0.3);
        }

        .login-btn:hover {
            background: linear-gradient(to right, var(--primary-dark), var(--primary-dark));
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(79, 126, 118, 0.4);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        .toggle-link {
            margin-top: 1.5rem;
            text-align: center;
            font-size: 0.95rem;
        }

        .toggle-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .toggle-link a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        .cont {
            padding: 2rem;
            border-radius: 20px;
            backdrop-filter: blur(8px);
            background-color: rgba(0, 0, 0, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 1200px) {
            .login-image-section h2 {
                font-size: 2.5rem;
            }
            
            .login-image-section p {
                font-size: 1.1rem;
            }
        }

        @media (max-width: 992px) {
            .login-container {
                flex-direction: column;
                max-height: none;
            }

            .login-image-section {
                height: 300px;
                flex: none;
            }
            
            .login-form-section {
                padding: 2rem 1.5rem;
            }
            
            .form-card {
                padding: 2rem;
                max-width: 600px;
            }
        }

        @media (max-width: 768px) {
            .login-image-section {
                height: 250px;
            }
            
            .login-image-section h2 {
                font-size: 2.2rem;
            }
            
            .login-image-section .cont {
                padding: 1.5rem;
            }
            
            .form-card {
                padding: 1.5rem;
            }
        }

        @media (max-width: 480px) {
            .login-image-section {
                height: 220px;
            }
            
            .login-image-section h2 {
                font-size: 1.8rem;
            }
            
            .login-image-section p {
                font-size: 0.95rem;
            }
            
            .cont {
                padding: 1.2rem;
            }
            
            .form-card {
                padding: 1.2rem;
                border-radius: 12px;
            }
            
            .form-card h2 {
                font-size: 1.6rem;
            }
        }
    </style>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById('<%= txtLoginPass.ClientID %>');
            var eyeIcon = document.getElementById("eyeIcon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.innerHTML = "🙈"; 
            } else {
                passwordField.type = "password";
                eyeIcon.innerHTML = "👁️"; 
            }
        }
    </script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="login-container">
        <div class="login-image-section">
            <div class="cont">
                <h2>Welcome Back!</h2>
                <p>Sign in to access your account and explore our delicious culinary offerings prepared just for you.</p>
            </div>
        </div>

        <div class="login-form-section">
            <asp:UpdatePanel ID="upnlLogin" runat="server" UpdateMode="Conditional">
                <ContentTemplate>
                    <asp:ScriptManager ID="ScriptManager1" runat="server"></asp:ScriptManager>
                    <div class="form-card">
                        <h2>Account Login</h2>
                        
                        <hr />
                        <div class="form-group">
                            <asp:Label ID="lblmsg" runat="server" ForeColor="#E35A3C"></asp:Label>
                        </div>
                        <div class="form-group">
                            <label for="txtLoginEmail">Email Address</label>
                            <asp:TextBox ID="txtLoginEmail" runat="server" placeholder="Enter your email" autocomplete="email"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="rfvLoginEmail" runat="server" ControlToValidate="txtLoginEmail" ErrorMessage="Email is required" Display="Dynamic" ForeColor="#E35A3C" />
                            <asp:RegularExpressionValidator ID="revLoginEmail" runat="server" ControlToValidate="txtLoginEmail" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" ErrorMessage="Invalid email format" Display="Dynamic" ForeColor="#E35A3C" />
                        </div>
                        <div class="form-group">
                            <label for="txtLoginPass">Password</label>
                            <div class="password-container">
                                <asp:TextBox ID="txtLoginPass" runat="server" TextMode="Password" placeholder="Enter your password" CssClass="password-input" autocomplete="current-password"></asp:TextBox>
                                <button type="button" class="toggle-password" onclick="togglePassword()" id="eyeIcon">👁️</button>
                            </div>
                            <asp:RequiredFieldValidator ID="rfvLoginPass" runat="server" ControlToValidate="txtLoginPass" ErrorMessage="Password is required" Display="Dynamic" ForeColor="#E35A3C" />
                        </div>
                        <div class="remember-me">
                           <div><asp:CheckBox ID="chkRememberMe" runat="server" /><label for="chkRememberMe">Remember Me</label></div> 
                        </div>

                        <asp:Button ID="btnLogin" runat="server" Text="Sign In" CssClass="login-btn" OnClick="btnLogin_Click" />
                        <div class="toggle-link">
                            <a href="Register.aspx">Don't have an account? Create one now</a>
                        </div>
                    </div>
                </ContentTemplate>
            </asp:UpdatePanel>
        </div>
    </div>
</asp:Content>