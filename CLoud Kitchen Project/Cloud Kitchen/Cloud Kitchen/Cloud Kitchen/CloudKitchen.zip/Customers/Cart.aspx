﻿<%@ Page Title="Your Cart" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master"
    CodeBehind="Cart.aspx.vb" Inherits="Cloud_Kitchen.Cart" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style type="text/css">
        .hero {
            width: 100%;
            height: 300px;
            background: url('../Images/cp8.jpeg') no-repeat top center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3);
            //backdrop-filter:blur(10px);
        }

        .hero-text {
            background: rgba(0, 0, 0, 0.5);
            padding: 20px 30px;
            border-radius: 10px;
        }

        .cart-container {
            max-width: 900px;
            margin: -50px auto 40px;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .cart-container h2 {
            text-align: center;
            color: #333;
            font-weight: 600;
            font-size: 30px;
        }

        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .cart-img {
            width: 150px;
            height: 120px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid #eee;
        }

        .cart-item-details {
            flex: 1;
            margin-left: 15px;
        }

        .cart-item h3 {
            font-size: 18px;
            color: #444;
            margin: 0;
        }

        .cart-item p {
            margin: 5px 0;
            color: #666;
            font-size: 14px;
        }

        .quantity-box {
            width: 50px;
            text-align: center;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .update-btn, .remove-btn, .checkout-btn {
            background-color: #ff6600;
            color: #fff;
            padding: 8px 14px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
        }

        .update-btn:hover, .remove-btn:hover, .checkout-btn:hover {
            background-color: #e65c00;
        }

        .remove-btn {
            background-color: #ff3333;
        }

        .remove-btn:hover {
            background-color: #cc0000;
        }

        .cart-footer {
            text-align: right;
            padding: 15px;
            font-size: 18px;
            font-weight: bold;
        }

        .cart-footer .checkout-btn {
            font-size: 16px;
        }

        .form-group {
            margin: 15px 0;
        }

        .form-group label {
            font-size: 16px;
            font-weight: bold;
        }

        .form-group input, .form-group select {
            width: 90%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        
        
        
        .update-panel {
            animation: fadeIn 0.8s ease-out, slideDown 0.5s ease-out;
            position: fixed; 
            top: 10%;
            left: 30%;
           //transform: translate(-50%, -50%);
            padding: 30px;
            background: #ffffff; 
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4); 
            max-width: 600px;
            width: 80%;
            z-index: 2050; 
            max-height: 80vh;
            margin-bottom:5%;
            overflow-y: auto;
        }        
         .payment-box {
            width: 550px;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
        }
        .payment-box h3 {
            text-align: center;
            margin-bottom: 15px;
        }
        .input-group {
            margin-bottom: 10px;
        }
        .input-group label {
            display: block;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight:bold;
        }
        .input-group input , .input-group .txtarea {
            width: 95%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 14px;
        }
        .card-number input {
            width: 21%;
            display: inline-block;
            text-align: center;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
        .button-group button {
            width: 48%;
            padding: 10px;
            font-size: 14px;
            border: none;
            cursor: pointer;
            border-radius: 3px;
        }
        .btn-cancel {
            background: orange;
            color: white;
        }
        .btn-pay 
        {
            
            background: green;
            color: white;
        }
        #lblTransaction {
            text-align: center;
            font-weight: bold;
            color: green;
            display: none;
        }
        
                .back-link {
            text-decoration: none;
            color: #4F7E76;
            display: block;
            text-align: center;
            margin-top: 20px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
                .empty-cart {
            text-align: center;
            margin-top: 50px;
        }

        .empty-cart img {
            width: 220px;
        }

        .empty-cart p {
            font-size: 18px;
            color: #666;
            margin-top: 10px;
        }


    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="hero">
        <div class="hero-text">
            🍽️ <span>Your favorite meals, just a click away!</span>
        </div>
    </div>
    <asp:Panel ID="pnlfill" runat="server">
    
    <div class="cart-container">
        <h2>
            Your Cart 🛒</h2>
        <asp:Repeater ID="rptCartItems" runat="server">
            <ItemTemplate>
                <div class="cart-item">
                    <img src='<%# GetValue(Container.DataItem, "m_image_url") %>' alt="Dish" class="cart-img">
                    <div class="cart-item-details">
                        <h3>
                            <%# GetValue(Container.DataItem, "m_name") %></h3>
                        <p>
                            Price: ₹<%# GetValue(Container.DataItem, "m_final_price") %></p>
                        <p>
                            Quantity:
                            <asp:TextBox ID="txtQuantity"  MaxLength=2 runat="server" Text='<%# GetValue(Container.DataItem, "quantity") %>'
                                CssClass="quantity-box"></asp:TextBox>
                            <asp:Button ID="btnUpdate" runat="server" Text="Update" CommandArgument='<%# GetValue(Container.DataItem, "m_id") %>'
                                OnCommand="UpdateCartItem" CssClass="update-btn" />
                        </p>
                        <p>
                            Total: ₹<%# GetValue(Container.DataItem, "total_price") %></p>
                    </div>
                    <asp:Button ID="btnRemove" runat="server" Text="❌ Remove" CommandArgument='<%# GetValue(Container.DataItem, "m_id") %>'
                        OnCommand="RemoveCartItem" CssClass="remove-btn" />
                </div>
            </ItemTemplate>
        </asp:Repeater>
        <asp:UpdatePanel ID="UpdatePanel2" runat="server">
            <ContentTemplate>
                <div class="cart-footer">
                    Grand Total: ₹<asp:Label ID="lblTotalPrice" runat="server" Text="0"></asp:Label>
                </div>
                <div class="cart-footer">
                    <a href="Menu.aspx" class="back-link">⬅ Continue Shopping</a>
                </div>
                <h2>
                    Delivery Details 🚚</h2>
                <label>
                    <b>Address:</b></label>
                <div class="form-group-row">
                    <div class="form-group">
                        <asp:TextBox ID="txtAddress" runat="server" TextMode="MultiLine" Rows="3" Style="width: 96%;
                            resize: none; border: 1px solid #000;"></asp:TextBox>
                        <asp:RequiredFieldValidator ID="rfvAddress" runat="server" ControlToValidate="txtAddress"
                            ErrorMessage="Address is required" CssClass="error-message" Display="Dynamic"
                            ValidationGroup="DeliveryDetails" ForeColor="red"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <div class="form-group-row">
                    <div class="form-group">
                        <label>
                            Pincode:</label>
                        <asp:DropDownList ID="ddlpincode" runat="server">
                            <asp:ListItem Text="🌍 All Pincodes" Value="0"></asp:ListItem>
                        </asp:DropDownList>
                        <%--<asp:TextBox ID="txtPincode" runat="server" AutoPostBack="true"></asp:TextBox>--%>
                        <asp:RequiredFieldValidator ID="rfvPincode" runat="server" ControlToValidate="ddlpincode"
                            ErrorMessage="Pincode is required" CssClass="error-message" InitialValue="" Display="Dynamic"
                            ValidationGroup="DeliveryDetails" ForeColor="red"></asp:RequiredFieldValidator>
                    </div>
                    <div class="form-group">
                        <label>
                            Payment Type:</label>
                        <asp:DropDownList ID="ddlPaymentType" runat="server" AutoPostBack="true">
                            <asp:ListItem Value="">💵 -- Select Payment Type --</asp:ListItem>
                            <asp:ListItem Value="Cash on Delivery">Cash on Delivery</asp:ListItem>
                            <asp:ListItem Value="Card Payment">Card Payment</asp:ListItem>
                        </asp:DropDownList>
                        <asp:RequiredFieldValidator ID="rfvPaymentType" runat="server" ControlToValidate="ddlPaymentType"
                            ErrorMessage="Please Select Payment method" CssClass="error-message" InitialValue=""
                            Display="Dynamic" ValidationGroup="DeliveryDetails" ForeColor="red"></asp:RequiredFieldValidator>
                    </div>
                </div>
                <style>
                    .form-group-row {
                        display: flex;
                        justify-content: space-between;
                        gap: 15px;
                        align-items: center;
                    }

                    .form-group {
                        flex: 1;
                    }

                    .form-group input,
                    .form-group select {
                        width: 90%;
                        padding: 8px;
                        font-size: 14px;
                        border: none;
                        border-bottom:3px solid #333;
                        border-bottom-color:#4F7E76;
                        //border-radius: 5px;
                    }

                    @media (max-width: 768px) {
                        .form-group-row {
                            flex-direction: column;
                        }
                    }
    
                    .overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.7); /* Dark overlay */
                    display: none;
                    z-index: 2000; /* Behind panel but above page */
                }

                .btn1
                {
                   // width:240px;
                    padding:15px 25px;
                    background-color:#4F7E76;
                    }

                body.modal-open {
                    overflow: hidden;
                }


                .success-panel {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 300px;
                    width:500px;
                }

                .success-box {
                    text-align: center;
                    background: #ffffff;
                    padding: 30px;
                    border-radius: 10px;
                    //box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
                    max-width: 450px;
                }

                .success-icon {
                    width: 80px;
                    height: 80px;
                }

                .success-message {
                    font-size: 25px;
                    font-weight: bold;
                    color: #28a745;
                }

                .success-text {
                    font-size: 17px;
                    color: #555;
                    margin-top: 10px;
                }

                .transaction-id {
                    font-weight: bold;
                    color: #333;
                }

                .btn-success {
                    background-color: #28a745;
                    color: white;
                    padding: 10px 20px;
                    border-radius: 5px;
                    cursor: pointer;
                    border: none;
                    transition: 0.3s;
                }

                .btn-success:hover {
                    background-color: #218838;
                }
                
                
                
.loader-box {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 200px;
}

.spinner {
    width: 50px;
    height: 50px;
    border: 5px solid #f3f3f3;
    border-top: 5px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.loading-text {
    margin-top: 10px;
    font-size: 18px;
    color: #555;
    font-weight: bold;
}


                </style>

                <%--<asp:Button ID="Button1" runat="server" CssClass="checkout-btn" Text="Proceed To Checkout" />--%>
                <asp:ScriptManager ID="ScriptManager1" runat="server">
                </asp:ScriptManager>
                <div id="overlay" class="overlay">
                </div>

<%--                <asp:Panel ID="Panel2" runat="server" CssClass="update-panel success-panel" Visible="False">
                    <center>
                        <div class="success-box">
                            <img src="../icons/complete.png" alt="Success" class="success-icon" />
                            <h2 class="success-message">Payment Successful!</h2>
                            <p class="success-text">
                                Your card details have been verified successfully.<br />
                                Thank you for your order!
                            </p>
                            <asp:Label ID="Label2" runat="server" CssClass="transaction-label" Visible="False"></asp:Label>
                            <asp:Label ID="lblTransaction" runat="server" CssClass="transaction-id" Visible="False"></asp:Label>
                            <br /><br />
                            <asp:Button ID="Button1" runat="server" Text="Okay" CssClass="btn-success checkout-btn"
                                OnClientClick="closePanel(); return false;" />
                        </div>
                    </center>
                </asp:Panel>--%>

<asp:UpdatePanel ID="UpdatePanel1" runat="server">
    <ContentTemplate>
                <asp:Panel ID="Panel2" runat="server" CssClass="update-panel success-panel" Visible="False">
    <center>
        <!-- Loader (Initially Visible) -->
        <div id="dvLoader" runat="server" class="loader-box">
            <div class="spinner"></div>
            <h3 class="loading-text">Processing Payment...</h3>
        </div>

        <!-- Success Message (Initially Hidden) -->
        <div id="dvSuccess" runat="server" class="success-box" visible="false">
            <img src="../icons/complete.png" alt="Success" class="success-icon" />
            <h2 class="success-message">Payment Successful!</h2>
            <p class="success-text">
                Your card details have been verified successfully.<br />
                Thank you for your order!
            </p>
            <asp:Label ID="Label2" runat="server" CssClass="transaction-label" Visible="False"></asp:Label>
            <asp:Label ID="lblTransaction" runat="server" CssClass="transaction-id" Visible="False"></asp:Label>
            <br /><br />
            <asp:Button ID="Button1" runat="server" Text="Okay" CssClass="btn-success checkout-btn"
                OnClientClick="closePanel(); return false;" />
        </div>
    </center>
</asp:Panel>
        <asp:Timer ID="Timer1" runat="server" Interval="3000" Enabled="False" OnTick="Timer1_Tick"></asp:Timer>

    </ContentTemplate>
</asp:UpdatePanel>



                <script type="text/javascript">
                    function showPanel() {
                        document.getElementById("overlay").style.display = "block";
                        document.getElementById('<%= Panel2.ClientID %>').style.display = "block";
                        document.body.classList.add("modal-open");
                    }

                    function closePanel() {
                        document.getElementById("overlay").style.display = "none";
                        document.getElementById('<%= Panel2.ClientID %>').style.display = "none";
                        document.body.classList.remove("modal-open");
                    }

                </script>
                <asp:Panel ID="up" runat="server" CssClass="update-panel" Visible="False">
                    <div class="input-group">
                        <center>
                <asp:Label ID="label1" runat="server" CssClass="transaction-label" Visible="False"></asp:Label></center>
                    </div>
                    <asp:Panel ID="Panel1" runat="server" Visible="false">
                    
                        <h3 align="center">CARD DETAILS</h3>
                        
                        <hr color="#4F7E76" size="3" width="100%" />
                        <div class="payment-box">
                            <div class="input-group">
                                <label>
                                    Credit Card Number</label>
                                <div class="card-number">
                                    <asp:TextBox ID="txtCard1" runat="server" MaxLength="4" CssClass="card-input"></asp:TextBox>
                                    <asp:TextBox ID="txtCard2" runat="server" MaxLength="4" CssClass="card-input"></asp:TextBox>
                                    <asp:TextBox ID="txtCard3" runat="server" MaxLength="4" CssClass="card-input"></asp:TextBox>
                                    <asp:TextBox ID="txtCard4" runat="server" MaxLength="4" CssClass="card-input"></asp:TextBox>
                                    <!-- Credit Card Number Validation -->
<%--                                    <asp:RequiredFieldValidator ID="rfvCard1" runat="server" ControlToValidate="txtCard1"
                                        ForeColor="Red" ErrorMessage="Card number required" ValidationGroup="PaymentGroup"
                                        Display="Dynamic" />
                                    <asp:RequiredFieldValidator ID="rfvCard2" runat="server" ControlToValidate="txtCard2"
                                        ForeColor="Red" ErrorMessage="Card number required" ValidationGroup="PaymentGroup"
                                        Display="Dynamic" />
                                    <asp:RequiredFieldValidator ID="rfvCard3" runat="server" ControlToValidate="txtCard3"
                                        ForeColor="Red" ErrorMessage="Card number required" ValidationGroup="PaymentGroup"
                                        Display="Dynamic" />
                                    <asp:RequiredFieldValidator ID="rfvCard4" runat="server" ControlToValidate="txtCard4"
                                        ForeColor="Red" ErrorMessage="Card number required" ValidationGroup="PaymentGroup"
                                        Display="Dynamic" />

                                    <asp:RegularExpressionValidator ID="revCardNumber" runat="server" ControlToValidate="txtCard1"
                                        ForeColor="Red" ErrorMessage="Invalid card number in 1st box" ValidationGroup="PaymentGroup"
                                        ValidationExpression="\d{4}" Display="Dynamic" />
                                    <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtCard2"
                                        Display="Dynamic" ForeColor="Red" ErrorMessage="Invalid card number in 2nd box"
                                        ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" />
                                    <asp:RegularExpressionValidator ID="RegularExpressionValidator2" runat="server" ControlToValidate="txtCard3"
                                        Display="Dynamic" ForeColor="Red" ErrorMessage="Invalid card number in 3rd box"
                                        ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" />
                                    <asp:RegularExpressionValidator ID="RegularExpressionValidator3" runat="server" ControlToValidate="txtCard4"
                                        ForeColor="Red" Display="Dynamic" ErrorMessage="Invalid card number in 4rth box"
                                        ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" />--%>



                                                                        <!-- Validation Summary to Show a Single Error -->
                                <asp:ValidationSummary ID="vsCardValidation" runat="server" ForeColor="Red"
                                    HeaderText="Card Number Error:" ShowMessageBox="False" ShowSummary="True"
                                    ValidationGroup="PaymentGroup" />

                                <!-- Required Field Validators -->
                                <asp:RequiredFieldValidator ID="rfvCard" runat="server"
                                    ControlToValidate="txtCard1"
                                    ForeColor="Red" ErrorMessage="Card number is required"
                                    ValidationGroup="PaymentGroup" Display="None" />

                                <asp:RequiredFieldValidator ID="rfvCard2" runat="server"
                                    ControlToValidate="txtCard2"
                                    ForeColor="Red" ErrorMessage="Card number is required"
                                    ValidationGroup="PaymentGroup" Display="None" />

                                <asp:RequiredFieldValidator ID="rfvCard3" runat="server"
                                    ControlToValidate="txtCard3"
                                    ForeColor="Red" ErrorMessage="Card number is required"
                                    ValidationGroup="PaymentGroup" Display="None" />

                                <asp:RequiredFieldValidator ID="rfvCard4" runat="server"
                                    ControlToValidate="txtCard4"
                                    ForeColor="Red" ErrorMessage="Card number is required"
                                    ValidationGroup="PaymentGroup" Display="None" />

                                <!-- Regular Expression Validators -->
                                <asp:RegularExpressionValidator ID="revCardNumber" runat="server"
                                    ControlToValidate="txtCard1" ForeColor="Red"
                                    ErrorMessage="Invalid card number (must be 4 digits each)"
                                    ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" Display="None" />

                                <asp:RegularExpressionValidator ID="revCardNumber2" runat="server"
                                    ControlToValidate="txtCard2" ForeColor="Red"
                                    ErrorMessage="Invalid card number (must be 4 digits each)"
                                    ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" Display="None" />

                                <asp:RegularExpressionValidator ID="revCardNumber3" runat="server"
                                    ControlToValidate="txtCard3" ForeColor="Red"
                                    ErrorMessage="Invalid card number (must be 4 digits each)"
                                    ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" Display="None" />

                                <asp:RegularExpressionValidator ID="revCardNumber4" runat="server"
                                    ControlToValidate="txtCard4" ForeColor="Red"
                                    ErrorMessage="Invalid card number (must be 4 digits each)"
                                    ValidationGroup="PaymentGroup" ValidationExpression="\d{4}" Display="None" />

                                </div>
                            </div>
                            <div class="input-group">
                                <label>
                                    Expiry Month</label>
                                <asp:TextBox ID="txtExpiryMonth" runat="server" MaxLength="2" placeholder="MM"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvExpiryMonth" runat="server" ControlToValidate="txtExpiryMonth"
                                    ForeColor="Red" ErrorMessage="Expiry month required" ValidationGroup="PaymentGroup"
                                    Display="Dynamic" />
                                <asp:RegularExpressionValidator ID="revExpiryMonth" runat="server" ControlToValidate="txtExpiryMonth"
                                    ForeColor="Red" ErrorMessage="Invalid month (01-12)" ValidationGroup="PaymentGroup"
                                    Display="Dynamic" ValidationExpression="^(0[1-9]|1[0-2])$" />
                            </div>
                            <div class="input-group">
                                <label>
                                    Expiry Year</label>
                                <asp:TextBox ID="txtExpiryYear" runat="server" MaxLength="2" placeholder="YY"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvExpiryYear" runat="server" ControlToValidate="txtExpiryYear"
                                    ForeColor="Red" ErrorMessage="Expiry year required" ValidationGroup="PaymentGroup"
                                    Display="Dynamic" />
                                <asp:RegularExpressionValidator ID="revExpiryYear" runat="server" ControlToValidate="txtExpiryYear"
                                    ForeColor="Red" ErrorMessage="Invalid year (e.g., 24, 25)" ValidationGroup="PaymentGroup"
                                    Display="Dynamic" ValidationExpression="^\d{2}$" />
                            </div>
                            <div class="input-group">
                                <label>
                                    CVV</label>
                                <asp:TextBox ID="txtCCV" runat="server" MaxLength="3" placeholder="CVV"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvCCV" runat="server" ControlToValidate="txtCCV"
                                    ForeColor="Red" ErrorMessage="CvV required" ValidationGroup="PaymentGroup" />
                                <asp:RegularExpressionValidator ID="revCCV" runat="server" ControlToValidate="txtCCV"
                                    ForeColor="Red" ErrorMessage="Invalid CCV (3 digits)" ValidationGroup="PaymentGroup"
                                    ValidationExpression="^\d{3}$" />
                            </div>
                            <div class="input-group">
                                <label>
                                    Name on Card</label>
                                <asp:TextBox ID="txtCardName" runat="server" placeholder="Full Name"></asp:TextBox>
                                <asp:RequiredFieldValidator ID="rfvCardName" runat="server" ControlToValidate="txtCardName"
                                    ForeColor="Red" ErrorMessage="Name required" ValidationGroup="PaymentGroup" />
                                <asp:RegularExpressionValidator ID="revCardName" runat="server" ControlToValidate="txtCardName"
                                    ForeColor="Red" ErrorMessage="Invalid name (letters only)" ValidationGroup="PaymentGroup"
                                    ValidationExpression="^[A-Za-z ]{3,50}$" />
                            </div>
                            <div class="button-group">
                                <asp:Button ID="btnPayNow" runat="server" Text="Verify Details" CssClass="btn-pay checkout-btn"
                                    OnClick="btnPayNow_Click" ValidationGroup="PaymentGroup" />
                            </div>
                        </div>
                    </asp:Panel>
                    <asp:Panel ID="Panel3" runat="server" Visible="false">
                        <div class="input-group">
                            <center>
                              <h3> <b>Total Amount :</b><asp:Label ID="lbltotamt" runat="server" CssClass="transaction-label" ></asp:Label></h3></center>
                        </div>
                        <div class="input-group">
                            <label>
                                Card Pin :
                            </label>
                            <asp:TextBox ID="txtpin" runat="server" MaxLength="6" placeholder="Enter Transaction Pin" TextMode="Password"></asp:TextBox>
                            <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtpin" ForeColor="Red" ErrorMessage="Transaction Pin Required" ValidationGroup="PaymentGroup1" Display="Dynamic" />
                            <asp:RegularExpressionValidator ID="revPin" runat="server" ControlToValidate="txtpin" ForeColor="Red" ErrorMessage="PIN must be exactly 6 digits" ValidationGroup="PaymentGroup1" Display="Dynamic" ValidationExpression="^\d{6}$" />
                        </div>
                        <div class="button-group">
                            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn-cancel checkout-btn" OnClick="btnCancel_Click" />
                            <asp:Button ID="Button3" runat="server" Text="Pay Now" CssClass="btn-pay checkout-btn" ValidationGroup="PaymentGroup1" Enabled="False" />
                        </div>
                    </asp:Panel>
                </asp:Panel>
            </ContentTemplate>
        </asp:UpdatePanel>
        <asp:Button ID="btnCheckout" runat="server" Text="Proceed to Order" CssClass="checkout-btn btn1"
            ValidationGroup="DeliveryDetails" OnClick="Checkout_Click" />
    </div>

    </asp:Panel>
    <asp:Panel ID="pnlempty" runat="server" Visible="false">
        
        <div class="cart-container">
            <h2>Empty Cart 🛒</h2>

           <div class="empty-cart" >
            <img src="../icons/empty1.png" alt="Empty Cart">
            <p>Your cart is empty! 🛍️</p>
        </div>
        </div>

    </asp:Panel>

</asp:Content>
