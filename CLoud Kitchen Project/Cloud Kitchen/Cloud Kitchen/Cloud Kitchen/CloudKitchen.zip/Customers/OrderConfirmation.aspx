﻿<%@ Page Title="Order Confirmation" Language="vb" AutoEventWireup="false" MasterPageFile="~/Customers/Customer.Master" CodeBehind="OrderConfirmation.aspx.vb" Inherits="Cloud_Kitchen.OrderConfirmation" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <style style="text/css">
        
        .hero-section {
            background: url('../Images/lb8.jpeg') top/cover no-repeat;
            height: 300px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-size: 32px;
            font-weight: bold;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
        }

        .order-confirmation {
            max-width: 600px;
            margin: -80px auto 50px; 
            padding: 25px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.15);
            text-align: center;
            font-family: Arial, sans-serif;
            position: relative;
            z-index: 10;
        }

        .thank-you-icon {
            width: 80px;
            margin-bottom: 15px;
        }

        .thank-you-text {
            font-size: 28px;
            font-weight: bold;
            color: #333;
            margin-bottom: 8px;
        }

        .thank-you-subtext {
            font-size: 17px;
            color: #666;
            margin-bottom: 15px;
        }

        .order-details {
            font-size: 16px;
            margin-bottom: 15px;
            color: #444;
            text-align: left;
            padding: 0 20px;
        }

        .order-status {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }

        .status-pending {
            color: #ff9800; 
        }

        .status-success {
            color: #4CAF50; 
        }

        .btn-track {
            display: inline-block;
            margin-top: 15px;
            padding: 12px 24px;
            font-size: 16px;
            color: #fff;
            background: #007BFF;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            transition: 0.3s ease-in-out;
        }

        .btn-track:hover {
            background: #0056b3;
        }

        .divider {
            height: 1px;
            background: #ddd;
            margin: 20px 20px;
        }

        @media (max-width: 768px) {
            .hero-section {
                font-size: 26px;
                height: 200px;
            }
            
            .order-confirmation {
                width: 90%;
                margin: -60px auto 40px;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    
    <div class="hero-section">
         <img src="../icons/burger.png" alt="Thank You" class="thank-you-icon" /> Order Confirmation
    </div>

    <div class="order-confirmation">
        <img src="../icons/logo.gif" alt="Thank You" class="thank-you-icon" />
        <div class="thank-you-text">Thank You for Your Order!</div>
        <div class="thank-you-subtext">Your delicious meal is on the way. 🍽️</div>

        <div class="divider"></div>

        <div class="order-details">
            <p><strong>Order ID:</strong> <asp:Label ID="lblOrderId" runat="server"></asp:Label></p>
            <p><strong>Transaction Number:</strong> <asp:Label ID="lblTransactionNumber" runat="server"></asp:Label></p>
            <p><strong>Total Amount:</strong> ₹<asp:Label ID="lblTotalAmount" runat="server"></asp:Label></p>
            <p><strong>Order Status:</strong> <asp:Label ID="lblOrderStatus" runat="server" CssClass="order-status"></asp:Label></p>
        </div>

        <div class="divider"></div>

        <asp:Panel ID="pnlPendingMessage" runat="server" Visible="false">
            <p class="status-pending">Your order is currently <b>Pending</b>. We are preparing it and will update you soon.</p>
            <asp:Button ID="btnTrackOrder" runat="server" CssClass="btn-track" Text="Track My Order" PostBackUrl="MyOrders.aspx" />
        </asp:Panel>
    </div>

</asp:Content>
